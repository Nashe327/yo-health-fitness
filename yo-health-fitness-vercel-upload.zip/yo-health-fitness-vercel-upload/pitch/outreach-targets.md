# Outreach Target Categories

## Priority UAE Buyers

- Gym chains
- Boutique fitness studios
- Wellness clinics
- Physiotherapy groups
- Corporate wellness providers
- Luxury concierge companies
- Sports academies
- Fitness influencers
- Hotel wellness divisions
- Angel investors and family offices

## Global Strategic Buyers

- Gymshark
- Mindbody
- ClassPass
- Urban Company
- Fresha
- Trainerize
- MyFitnessPal-style wellness apps
- Wearable companies
- Fitness content brands

## Outreach Message

Subject: YO Health & Fitness marketplace app opportunity

Hi [Name],

I’m developing YO Health & Fitness, an all-in-one health, fitness, and wellness marketplace built for Dubai and the UAE.

The product combines trainer bookings, wellness professionals, gym discovery, AI coaching, corporate wellness, and premium concierge fitness into one mobile app.

I have a working React app, Supabase backend schema, Android Capacitor project, iOS packaging path, provider portal, corporate portal, trust center, sales package, pitch materials, and buyer-ready roadmap. I’m looking for a strategic buyer or launch partner who can take it to market.

Would you be open to a short call this week?

Best,  
[Your Name]

## Before Contacting Buyers

Prepare:

- Demo link
- 90-second demo video
- Pitch deck
- One-page summary
- Sale price range
- NDA template
- Code repository access rules

Do not send the source code until there is an NDA, purchase agreement, or serious written offer.
