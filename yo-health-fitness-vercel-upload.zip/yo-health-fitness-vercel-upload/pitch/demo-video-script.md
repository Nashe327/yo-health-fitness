# Demo Video Script

## Length

Target: 90 seconds.

## Script

YO Health & Fitness is an all-in-one health, fitness, and wellness marketplace built for Dubai and the UAE.

Instead of using separate apps for trainers, gyms, nutrition, recovery, and health tracking, users get one connected wellness command center.

First, the client opens the dashboard: body metrics, sleep, stress, bookings, and progress toward their goal. They can also log a new health metric.

Next, they open the marketplace and search for verified professionals: personal trainers, yoga instructors, Pilates instructors, nutritionists, physiotherapists, boxing coaches, and wellness experts.

They can filter by service type, location, and budget, then open a provider profile, choose availability, request a booking, and prepare a hosted checkout record.

The gym marketplace helps users compare facilities, pricing, reviews, and premium gym partners.

The AI coach turns wellness data into weekly recommendations for calories, training, cardio, and recovery.

For providers, the portal shows listing edits, availability publishing, booking requests, and payouts.

For companies, the corporate portal manages employee wellness, challenges, screenings, and executive reporting.

For launch readiness, the trust center includes privacy, terms, health disclaimer, consent records, and account deletion requests.

For selling the product, the Sell tab includes valuation modeling, demo script, outreach CRM, and handoff checklist.

For operators, the admin dashboard shows provider approvals, bookings, payments, revenue, and operational records.

The business model includes booking commissions, provider subscriptions, featured listings, gym partnerships, AI memberships, corporate wellness, and luxury concierge services.

YO Health & Fitness is ready for a strategic buyer or launch partner who can bring it to market across Dubai and the UAE.

## Shots To Record

1. Login screen
2. Dashboard
3. Provider marketplace filters
4. Booking drawer
5. Gym marketplace
6. AI coach sliders
7. Provider portal
8. Corporate portal
9. Trust center
10. Sell tab
11. Admin dashboard
12. Final slide with contact details
