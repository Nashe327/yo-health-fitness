# Production Environment Checklist

Date: 2026-06-30

Before creating App Store or Google Play builds, create a production Supabase project and configure these values in `.env`:

```text
VITE_SUPABASE_URL=https://your-production-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your-production-publishable-key
VITE_ENABLE_DEMO_ACCESS=false
```

## Required Production Setup

- Run `docs/supabase-schema.sql` in a fresh production Supabase project.
- For an existing project, run `docs/supabase-live-update-2026-06-30.sql`.
- Complete `docs/supabase-production-hardening.md`.
- Confirm RLS is enabled on all tables.
- Create real admin account and set `profiles.role = 'admin'`.
- Create demo reviewer account with limited permissions.
- Disable preview access with `VITE_ENABLE_DEMO_ACCESS=false`.
- Remove any real user data from demo builds.
- Configure production privacy policy URL.
- Configure production terms URL.
- Complete `docs/legal-compliance-launch-pack.md`.
- Configure support email.
- Configure hosted payment provider outside the app.
- Complete `docs/payment-provider-integration.md` and store payment secrets only in backend/Supabase Edge Function environment variables.

## Do Not Commit

- Supabase service role keys.
- Payment provider secret keys.
- Apple signing certificates.
- Google Play signing keys.
- Real user health data.
- Real provider identity documents.

## Mobile Build Commands

Android:

```bash
pnpm mobile:android
pnpm cap:open:android
```

iOS, after Xcode and CocoaPods are installed:

```bash
pnpm cap:add:ios
pnpm mobile:ios
pnpm cap:open:ios
```
