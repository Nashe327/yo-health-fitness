# Outreach Message Pack

Use these as starting messages. Personalize each one before sending.

## Gym Chain

Subject: UAE fitness marketplace MVP for gym growth

Hi [Name],

I built YO Health & Fitness, a working health and fitness marketplace MVP designed for the UAE. It combines trainer bookings, gym discovery, provider operations, payments, corporate wellness, and a mobile app path.

I think a gym chain could use this to turn members and local providers into a larger digital wellness ecosystem.

Would you be open to a short demo?

Best,  
[Your Name]

## Wellness Clinic

Subject: Digital wellness marketplace opportunity

Hi [Name],

I’m building YO Health & Fitness, a UAE-ready marketplace that connects clients with trainers, physiotherapists, nutritionists, recovery services, health metrics, and corporate wellness programs.

For a clinic group, the app could become a lead-generation and patient engagement layer for physio, nutrition, screenings, and recovery services.

Would you be open to reviewing a 90-second demo?

Best,  
[Your Name]

## Corporate Wellness Company

Subject: Corporate wellness platform MVP

Hi [Name],

I’ve built YO Health & Fitness, a working MVP with a corporate wellness portal for employee rosters, challenges, screenings, aggregate reports, bookings, and provider management.

I’m looking for a strategic buyer or partner who can take it to market with existing corporate clients.

Could I send you a short demo video?

Best,  
[Your Name]

## Fitness Brand

Subject: YO Health & Fitness UAE marketplace concept

Hi [Name],

I built a working MVP called YO Health & Fitness: a UAE-focused wellness marketplace combining fitness professionals, gyms, corporate wellness, AI guidance, concierge services, and mobile packaging.

For a fitness brand, this could become a community-to-services platform in Dubai and the UAE.

Would you be open to a quick intro?

Best,  
[Your Name]

## Investor Or Venture Studio

Subject: Working UAE wellness marketplace MVP

Hi [Name],

I’ve built a working MVP for YO Health & Fitness, an all-in-one UAE health, fitness, and wellness marketplace. It includes client dashboard, provider booking, payments preparation, provider portal, corporate portal, trust center, sales package, Supabase backend, and Android packaging.

I’m exploring sale, partnership, or launch support.

Would you be open to a short demo?

Best,  
[Your Name]
