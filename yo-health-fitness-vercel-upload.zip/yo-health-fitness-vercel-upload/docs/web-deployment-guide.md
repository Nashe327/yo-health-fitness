# YO Health & Fitness Web Deployment Guide

Use this to publish the app and pitch page so you can send a real URL to gyms, clinics, investors, corporate buyers, and potential acquirers.

## Recommended First Deploy

Use Vercel or Netlify for the first hosted MVP. Both work well with Vite and Supabase.

The app includes:

- `vercel.json` for direct route support such as `/pitch`.
- `public/_redirects` for Netlify direct route support.

## Build Settings

Framework preset:

```text
Vite
```

Build command:

```text
npm run build
```

Output directory:

```text
dist
```

## Environment Variables

Add these in the hosting dashboard:

```text
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your-publishable-key
VITE_ENABLE_DEMO_ACCESS=false
VITE_PAYMENT_PROVIDER=stripe
```

Use the publishable or anon key only. Do not put the Supabase service role key in Vercel, Netlify, or the frontend app.

## Important URLs

Public pitch page:

```text
https://your-domain.com/pitch
```

App login:

```text
https://your-domain.com/
```

Privacy policy and terms should be published before App Store or Google Play submission. Until a separate marketing site exists, you can publish them as pages on the same domain or use a simple hosted document.

## Vercel Steps

1. Push the project to GitHub.
2. Open Vercel.
3. Click `Add New Project`.
4. Import the GitHub repository.
5. Set framework preset to `Vite`.
6. Add the environment variables above.
7. Deploy.
8. Open `/pitch` directly and confirm it loads.
9. Submit the early-access form and confirm a row appears in Supabase `waitlist_signups`.

## Netlify Steps

1. Push the project to GitHub.
2. Open Netlify.
3. Click `Add new site`.
4. Import the GitHub repository.
5. Set build command to `npm run build`.
6. Set publish directory to `dist`.
7. Add the environment variables above.
8. Deploy.
9. Open `/pitch` directly and confirm it loads.
10. Submit the early-access form and confirm a row appears in Supabase `waitlist_signups`.

## Production Safety

Before sharing widely:

- Keep `VITE_ENABLE_DEMO_ACCESS=false`.
- Create real reviewer/admin accounts manually.
- Confirm Supabase RLS policies are enabled.
- Confirm the waitlist form saves without exposing private tables.
- Publish privacy policy and terms URLs.
- Do not show demo admin access to public visitors.

## Buyer Demo Flow

Send this URL first:

```text
https://your-domain.com/pitch
```

Then offer app access only after the buyer, partner, or investor asks for a deeper demo.
