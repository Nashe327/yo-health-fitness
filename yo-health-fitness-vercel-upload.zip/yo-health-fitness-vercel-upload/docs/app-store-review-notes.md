# App Store And Play Review Notes

Date: 2026-06-30

## App Identity

- App name: YO Health & Fitness
- Bundle/package ID: `com.yohealthfitness.app`
- Category: Health & Fitness / Lifestyle
- Target market: UAE first, Dubai launch focus

## Demo Account

Use this for app review until production auth accounts are created:

- Email: `demo@yohealthfitness.com`
- Password: `demo12345`

Admin/demo mode is available from the login screen during review builds. Remove or hide admin access before public launch unless the reviewer account is intentionally admin-scoped.

## What The App Does

YO Health & Fitness helps users discover and book fitness and wellness providers, compare gyms, track wellness metrics, request premium concierge services, join corporate wellness programs, and manage provider/admin operations.

## Health And Medical Positioning

The app is a wellness marketplace and coaching support product. It is not positioned as a medical device and does not diagnose, treat, prevent, or cure disease. Health metrics, AI guidance, nutrition, physiotherapy, recovery, and screening content must include disclaimers and qualified-provider workflows before production launch.

## Permissions

Current Android manifest only requests internet access:

- `android.permission.INTERNET`

No camera, location, contacts, microphone, Bluetooth, or background tracking permissions are required for the current MVP.

## Data Collected

Expected data categories:

- Account details: email, name, phone, role.
- Wellness profile: goals, body/health/fitness metrics users choose to enter.
- Booking data: provider, service, date/time, location type, notes.
- Payment records: amount, status, provider payout, reference. Card data should be handled only by a hosted payment provider.
- Hosted checkout links: generated in test/demo mode until a live UAE payment provider is connected.
- Provider data: listing profile, availability, verification document links.
- Support and trust data: consent records, deletion requests, support tickets.

## Account Deletion

The Trust Center includes an account deletion request flow. For production, connect this to an operational deletion process and publish a support email.

## External Services

- Supabase for auth, database, and backend records.
- Future hosted payment provider: Stripe, Tap, Checkout.com, Ziina, or Network International.
- The app does not collect or store raw card data.

## Review Notes

Ask reviewers to test:

- Sign in or use preview/demo mode.
- Use the login role switcher to preview Client, Provider, Corporate, and Admin workspaces.
- Browse Marketplace and open a provider.
- Create a booking request.
- Open booking confirmation and create a hosted checkout record.
- Visit Provider tab and submit verification document evidence.
- Visit Admin tab and review provider/document queues.
- Submit a provider review from booking confirmation and approve/reject it in Admin.
- Visit Trust Center and confirm privacy, terms, disclaimer, consent, and deletion request flows.

## Production Changes Before Public Launch

- Replace preview/demo admin access with real role-based accounts.
- Connect live payment provider.
- Add production privacy policy and terms URLs.
- Complete legal and healthcare compliance review.
- Test on real iOS and Android devices.
- Complete App Store privacy labels and Google Play Data Safety form.
