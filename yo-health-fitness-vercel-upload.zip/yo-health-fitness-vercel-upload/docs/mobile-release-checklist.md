# Mobile Release Checklist

## iOS

1. Create Apple Developer account.
2. Install Xcode.
3. Install CocoaPods with `brew install cocoapods`.
4. Run `pnpm install`.
5. Run `pnpm build`.
6. Run `pnpm cap:add:ios`.
7. Run `pnpm cap:sync`.
8. Run `pnpm cap:open:ios`.
9. Configure bundle ID: `com.yohealthfitness.app`.
10. Add app icons and launch screen.
11. Configure Apple Sign In if used.
12. Add privacy labels in App Store Connect.
13. Upload build from Xcode.
14. Test with TestFlight.
15. Submit for App Store Review.

Current status:

- Capacitor iOS dependency is installed.
- `ios/` native folder is not generated yet.
- `pnpm cap:add:ios` is blocked on this machine until CocoaPods is installed.

## Android

1. Create Google Play Console account.
2. Install Android Studio.
3. Run `pnpm install`.
4. Run `pnpm build`.
5. Run `pnpm cap:add:android`.
6. Run `pnpm cap:sync`.
7. Run `pnpm cap:open:android`.
8. Configure package name: `com.yohealthfitness.app`.
9. Add adaptive app icon.
10. Create signed release build.
11. Complete Data Safety form.
12. Upload to Play Console.
13. Run internal testing.
14. Submit for review.

Current status:

- `android/` native folder exists.
- Latest web build has been synced into Android.
- Android Studio is still needed for signing, release build, and Play Console upload.

## Store Materials Needed

- App name
- Short description
- Full description
- Screenshots
- App icon
- Privacy policy URL
- Terms URL
- Health disclaimer
- Demo account for Apple review
- Support email
- Marketing website
- Apple privacy label answers: `docs/apple-privacy-label-draft.md`
- Google Play Data Safety answers: `docs/google-play-data-safety-draft.md`
- Screenshot plan: `docs/store-screenshot-plan.md`
- Reviewer account plan: `docs/reviewer-account-plan.md`

## Store Compliance Gates

- Complete `docs/app-store-review-notes.md`.
- Complete `docs/mobile-qa-plan.md`.
- Complete `docs/store-screenshot-plan.md`.
- Complete `docs/reviewer-account-plan.md`.
- Confirm App Store privacy labels match Supabase data collection.
- Confirm Google Play Data Safety form matches Supabase data collection.
- Disable or protect preview admin access before public launch.
- Ensure live payment flow uses hosted checkout and never stores raw card data.
- Ensure medical, nutrition, physiotherapy, and health-screening claims are lawyer/compliance reviewed.
