# YO Health & Fitness Dubai Business Launch Plan

Date: 2026-06-30

This plan turns the app from a sellable MVP into a launchable UAE business. It is not legal, tax, medical, or financial advice; use it as the operating checklist for discussions with a UAE lawyer, accountant, payment provider, and compliance advisor.

## Launch Position

YO Health & Fitness should launch first as a wellness booking marketplace, not as a medical provider. The app can list personal trainers, yoga instructors, Pilates instructors, sports coaches, gyms, corporate wellness packages, and luxury concierge fitness services.

Treat nutrition coaching, physiotherapy, health screenings, blood metrics, injury recovery, and medical-style advice as regulated or higher-risk services until a UAE professional confirms the correct licensing, disclaimers, and provider requirements.

## Lean Launch Budget

Target lean setup budget: AED 45,000 to AED 120,000 before paid advertising.

Lower end assumes founder-led sales, limited legal review, no salaried staff, existing laptop, no office, and contractors only. Higher end assumes stronger legal/compliance review, brand design, mobile testing devices, app-store help, accounting, paid provider onboarding, and launch marketing.

Do not spend heavily before signing supply partners. The first milestone is not a big office; it is verified providers, pilot gyms, and paying or trial corporate clients.

## 90-Day Launch Roadmap

Before spending on company setup, use `docs/real-world-validation-pack.md` to run a 30-day proof sprint. The app becomes much easier to sell or fund if you can show provider interest, partner replies, client demand, and corporate pilot conversations.

### Days 1-14: Formation Decisions

- Decide whether to sell the software asset or launch the company yourself.
- Choose mainland vs free zone setup with a UAE business setup advisor.
- Confirm business activities for software platform, marketplace, fitness services, wellness services, and advertising.
- Ask a lawyer whether nutrition, physiotherapy, screenings, and AI health recommendations need extra controls.
- Select accountant and bookkeeping tool.
- Prepare founder one-page pitch and partner onboarding deck.

### Days 15-30: Business Infrastructure

- Register company and trade license.
- Open business bank account.
- Register accounting process for invoices, provider payouts, commissions, and corporate wellness contracts.
- Prepare corporate tax and VAT monitoring with an accountant.
- Choose payment provider shortlist: Stripe, Tap, Checkout.com, Ziina, or Network International.
- Finalize privacy policy, terms, provider agreement, client waiver, health disclaimer, and data deletion process.

### Days 31-60: Supply And Pilot Launch

- Sign 10 verified trainers or instructors.
- Sign 3 gyms as discovery or advertising partners.
- Sign 2 wellness clinics or physiotherapy/nutrition partners, subject to licensing confirmation.
- Sign 1-2 corporate wellness pilot clients.
- Run real test bookings manually with founder oversight.
- Verify provider certificates, IDs, insurance position, pricing, cancellation rules, and payout terms.
- Record customer testimonials and provider feedback.

### Days 61-90: Public Launch

- Connect live payments.
- Complete Android internal testing and iOS setup.
- Submit store listings after legal and privacy URLs are live.
- Launch a simple website landing page with support contact, privacy policy, terms, and founder pitch.
- Start direct outreach before paid ads: gyms, clinics, HR teams, hotel concierges, residential communities, and fitness creators.
- Track weekly KPIs and decide whether to raise, sell, partner, or keep operating.

## Minimum Team

- Founder / sales lead: signs providers, gyms, clinics, corporate pilots, and investors.
- Full-stack developer: app, Supabase, payments, app-store packaging, analytics.
- UAE lawyer: terms, privacy, provider contracts, disclaimers, health compliance.
- Accountant: company setup support, tax, VAT monitoring, invoicing, payouts.
- Part-time operations assistant: provider onboarding, booking support, client follow-up.

## Launch KPIs

- 20 verified providers.
- 5 gym or clinic partners.
- 2 corporate pilot leads.
- 50 completed test bookings.
- 30%+ repeat booking intent from early users.
- Less than 24-hour provider response time.
- Clear provider payout process.
- Zero unresolved safety/compliance incidents.

## Product Work Still Needed

- Live checkout integration.
- Email/SMS/push notifications.
- Production Supabase security review.
- Real user roles for client, provider, corporate admin, and platform admin.
- Provider document upload and verification workflow.
- Refunds, cancellations, dispute handling, and payout reconciliation.
- Mobile device QA on Android and iOS.
- App-store screenshots, privacy labels, and review notes.

## Sales Strategy

Start with partners who already have trust and customers:

- Gym chains and boutique studios.
- Physiotherapy and wellness clinic groups.
- Hotel and luxury concierge operators.
- Corporate wellness providers.
- HR departments in medium and large companies.
- Fitness brands exploring UAE expansion.

Primary pitch: YO Health & Fitness is an all-in-one UAE wellness marketplace with booking, providers, gyms, health dashboards, corporate wellness, premium concierge, admin operations, and mobile packaging already built as an MVP.

## Sell Or Operate Decision

If money is limited, use the next 30 days to improve the asset and collect validation, not to spend heavily. A stronger sellable package includes:

- Working demo URL.
- Demo video.
- Pitch deck.
- Supabase schema and seed data.
- Android project.
- iOS setup instructions.
- Real-world validation pack.
- First 30-day KPI sheet.
- Provider and partner outreach tracker.
- Corporate pilot proposal.
- Partner interest emails or letters of intent.
- List of verified providers willing to join.
- Legal/compliance notes showing what must be reviewed before launch.

With only code and idea, this is an MVP asset. With partner interest and pilot users, it becomes a business opportunity.

## Source Links To Review

- UAE Government business information: https://u.ae/en/information-and-services/business
- UAE Ministry of Economy business guidance: https://www.moec.gov.ae
- Invest in Dubai business services: https://invest.dubai.ae
- UAE Federal Tax Authority: https://tax.gov.ae
- Dubai Health Authority: https://www.dha.gov.ae
