# YO Health & Fitness Corporate Pilot Proposal

## Pilot Summary

YO Health & Fitness can run a 30-day wellness pilot for a company team using the existing platform, curated providers, corporate challenges, wellness check-ins, and aggregate reporting.

The pilot is designed to prove employee engagement before the company commits to a larger annual program.

## Best First Customer

Ideal pilot companies:

- 50 to 500 employees.
- Dubai or UAE-based team.
- HR, people operations, founder, or office manager cares about wellness.
- Employees are interested in fitness, weight loss, stress management, mobility, or lifestyle improvement.
- Company wants measurable engagement without building its own wellness platform.

## Pilot Package

Duration: 30 days

Includes:

- Corporate wellness dashboard.
- Employee roster setup.
- One wellness challenge.
- Provider booking access.
- Optional fitness, yoga, Pilates, nutrition, recovery, or coaching sessions.
- Weekly aggregate activity report.
- Employee feedback summary.
- End-of-pilot recommendations.

## Example Challenge Options

- 30-Day Steps Challenge.
- Stress Reset Challenge.
- Strength Starter Challenge.
- Desk Mobility Challenge.
- Summer Shred Challenge.
- Corporate Team Wellness Challenge.

## Pilot Success Metrics

Track:

- Employees invited.
- Employees activated.
- Challenge participants.
- Bookings requested.
- Sessions completed.
- Average engagement rate.
- Employee feedback score.
- HR satisfaction.
- Renewal or expansion interest.

## Commercial Options

Choose the option that fits the relationship:

- Free discovery pilot: useful for a strong brand logo or case study.
- Low-cost pilot: AED 2,500 to AED 7,500 for setup and reporting.
- Paid operational pilot: AED 10,000 to AED 25,000 if sessions, providers, and reporting are included.
- Annual program proposal: monthly platform fee plus provider session costs.

Actual pricing should depend on company size, provider costs, and whether YO Health & Fitness is handling bookings, support, and reporting manually.

## What The Company Provides

- One decision maker.
- Employee invite list or internal announcement.
- Wellness goals for the team.
- Approval to collect non-sensitive participation data.
- Feedback after the pilot.

## What YO Health & Fitness Provides

- Pilot setup.
- Demo access.
- Challenge setup.
- Provider recommendations.
- Booking coordination.
- Aggregate reporting.
- Post-pilot proposal.

## Compliance Note

The pilot should avoid medical claims. Health screenings, physiotherapy, nutrition plans, employee health data, and medical-style reports need legal and regulatory review before production use.

## Proposal Email

Subject: 30-day wellness pilot proposal

Hi [Name],

Thank you for reviewing YO Health & Fitness.

Based on our conversation, I suggest a simple 30-day corporate wellness pilot for [Company Name]. The goal is to test employee engagement with challenges, provider access, wellness bookings, and aggregate reporting before any larger commitment.

The pilot can include:

- Employee wellness challenge
- Provider booking access
- Weekly aggregate engagement report
- End-of-pilot feedback summary
- Expansion recommendation

Would you be open to reviewing a short pilot plan this week?

Best,  
[Your Name]
