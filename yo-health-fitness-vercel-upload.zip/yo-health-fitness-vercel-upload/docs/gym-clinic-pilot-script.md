# Gym, Clinic, And Provider Pilot Scripts

Use these messages to get real market replies. Keep them short, personal, and focused on one next action.

## Provider First Message

Hi [Name],

I am building YO Health & Fitness, a UAE-focused app where clients can book trusted trainers, instructors, coaches, and wellness professionals.

I am onboarding a small first group of providers for the demo and pilot. Your profile would include services, pricing, location, availability, photos, credentials, and booking requests.

Would you be open to being listed as one of the first providers?

Best,  
[Your Name]

## Provider Follow-Up

Hi [Name],

Just following up. I am preparing the first provider list for YO Health & Fitness this week.

If you are interested, I only need:

- Services offered
- Area or online availability
- Starting price
- Certifications or experience
- Profile photo or Instagram link
- Best WhatsApp or email for booking requests

Happy to send a quick preview.

Best,  
[Your Name]

## Gym Or Studio First Message

Subject: Pilot listing for [Gym/Studio Name]

Hi [Name],

I am building YO Health & Fitness, a UAE wellness marketplace that helps users discover gyms, studios, coaches, classes, and corporate wellness services in one app.

I am selecting a small group of gyms and studios for the first pilot. The app can show your facilities, membership pricing, reviews, class schedule, location, and featured placement.

Would you be open to a short demo and a pilot listing?

Best,  
[Your Name]

## Clinic First Message

Subject: Wellness and recovery marketplace pilot

Hi [Name],

I am building YO Health & Fitness, a UAE marketplace for fitness, recovery, wellness, and corporate health services.

For clinics, the platform can support discovery, booking requests, physiotherapy and recovery service listings, nutrition or screening packages, and corporate wellness leads, subject to the right licensing and compliance review.

Would you be open to a 15-minute demo?

Best,  
[Your Name]

## Corporate Wellness First Message

Subject: 30-day corporate wellness pilot

Hi [Name],

I am building YO Health & Fitness, an app for fitness bookings, wellness professionals, corporate challenges, health screenings, employee wellness dashboards, and provider management.

I am offering a small 30-day corporate pilot for companies that want a practical wellness program without building software internally.

Would you be the right person to review this, or should I speak with someone in HR or people operations?

Best,  
[Your Name]

## Buyer Or Strategic Partner First Message

Subject: Working UAE wellness marketplace MVP

Hi [Name],

I have built YO Health & Fitness, a working UAE-focused health, fitness, and wellness marketplace MVP.

It includes client dashboards, provider booking, gym discovery, corporate wellness, concierge fitness, admin operations, Supabase backend, Android packaging, and iOS release path.

I am looking for a strategic buyer or launch partner with distribution, providers, or capital.

Would you be open to seeing the demo?

Best,  
[Your Name]

## 15-Minute Call Flow

1. Ask what they currently use for bookings, client leads, wellness programs, or provider discovery.
2. Ask what is painful, expensive, manual, or missing.
3. Show the relevant part of the app only.
4. Ask what would make them try it.
5. Ask whether they would confirm interest by email or join a pilot list.

## Closing Question

"If I prepare a pilot version for your business, what would need to be true for you to say yes?"
