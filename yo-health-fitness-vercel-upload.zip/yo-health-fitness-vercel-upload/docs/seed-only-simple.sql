-- YO Health & Fitness seed-only script.
-- Run this in Supabase SQL Editor if the tables exist but are empty.

insert into public.providers (name, role, goal, location, budget, rating, price_aed, image_url, tags, status)
values
  ('Maya Haddad', 'Personal Trainer', 'Weight loss', 'Home visit', 'Premium', 4.9, 380, 'https://images.unsplash.com/photo-1594381898411-846e7d193883?auto=format&fit=crop&w=900&q=80', array['Fat loss', 'Strength', 'Dubai Marina'], 'verified'),
  ('Omar Khan', 'Boxing Coach', 'Athletic performance', 'Gym based', 'Mid-range', 4.8, 260, 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&w=900&q=80', array['Conditioning', 'Boxing', 'JLT'], 'verified'),
  ('Lina Martins', 'Pilates Instructor', 'Flexibility', 'Online', 'Budget', 4.7, 140, 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=900&q=80', array['Mobility', 'Core', 'Online'], 'pending'),
  ('Dr. Aisha Noor', 'Nutritionist', 'General health', 'Home visit', 'VIP', 5.0, 620, 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=900&q=80', array['Blood sugar', 'Meal plans', 'VIP'], 'verified'),
  ('Samir Patel', 'Physiotherapist', 'Recovery', 'Home visit', 'Premium', 4.9, 420, 'https://images.unsplash.com/photo-1571019613914-85f342c1d0bb?auto=format&fit=crop&w=900&q=80', array['Recovery', 'Mobility', 'Sports injury'], 'verified'),
  ('Nadine Rossi', 'Yoga Instructor', 'Stress management', 'Hotel', 'Premium', 4.8, 340, 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=900&q=80', array['Breathwork', 'Stress', 'Private'], 'verified');

insert into public.gyms (name, area, monthly_price_aed, rating, description, facilities, featured)
values
  ('Peak District Marina', 'Dubai Marina', 499, 4.8, 'Premium strength floor, recovery lounge, reformer Pilates, and HYROX classes.', array['Pool', 'Sauna', 'Valet', 'Classes'], true),
  ('Downtown Performance Lab', 'Downtown', 650, 4.9, 'Athletic performance gym with VO2 testing, coaching pods, and nutrition support.', array['VO2 Max', 'Sports science', 'Boxing', 'PT'], true),
  ('Jumeirah Wellness Club', 'Jumeirah', 390, 4.6, 'Quiet wellness club with yoga, swimming, mobility, and family memberships.', array['Yoga', 'Pool', 'Kids area', 'Cafe'], false);
