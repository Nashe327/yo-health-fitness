# Store Listing Draft

## App Name

YO Health & Fitness

## Subtitle

Book fitness, wellness, and health experts in one app.

## Short Description

Find trainers, yoga instructors, Pilates coaches, gyms, nutritionists, recovery services, and corporate wellness programs.

## Full Description

YO Health & Fitness brings health, fitness, and wellness services into one marketplace.

Clients can browse verified trainers and wellness professionals, compare gyms, request bookings, track body and health metrics, and receive AI-supported coaching recommendations. The platform is designed for the UAE market with premium Dubai services including home training, hotel sessions, villa programs, executive recovery, and corporate wellness.

For providers, YO Health & Fitness creates a direct channel for new clients, featured listings, subscriptions, and booking management. For gyms, clinics, and wellness companies, it creates a marketplace and lead-generation platform that can grow into a full health ecosystem.

## Key Features

- Book personal trainers, yoga instructors, Pilates instructors, nutritionists, massage therapists, physiotherapists, sports coaches, and wellness coaches.
- Search by provider type, location, and budget.
- Compare nearby gyms, facilities, classes, reviews, and pricing.
- Track weight, BMI, body fat, muscle mass, blood pressure, heart rate, sleep quality, stress, performance, and recovery.
- Use AI coaching insights to adjust workouts, calories, cardio, and recovery days.
- Request luxury concierge services for home, villa, hotel, and executive wellness.
- Manage corporate wellness challenges, health screenings, and employee wellbeing programs.

## Keywords

fitness, health, wellness, personal trainer, gym, Dubai, UAE, yoga, Pilates, nutrition, physiotherapy, corporate wellness, coaching

## Required Store Assets

- App icon: use `public/icons/icon-1024.png` as the source.
- iPhone screenshots: use `docs/store-screenshot-plan.md`.
- Android screenshots: use `docs/store-screenshot-plan.md`.
- Privacy policy URL.
- Terms URL.
- Support email.
- Reviewer accounts from `docs/reviewer-account-plan.md`.
- Account deletion path inside Profile or Trust Center.
- Health disclaimer visible before relying on AI or health metrics.
- Apple privacy label draft: `docs/apple-privacy-label-draft.md`.
- Google Play Data Safety draft: `docs/google-play-data-safety-draft.md`.

## Health Disclaimer

YO Health & Fitness provides wellness, booking, and coaching support. It is not a medical device and does not replace professional medical advice, diagnosis, or treatment. Users should consult qualified healthcare professionals before making medical or major lifestyle decisions.
