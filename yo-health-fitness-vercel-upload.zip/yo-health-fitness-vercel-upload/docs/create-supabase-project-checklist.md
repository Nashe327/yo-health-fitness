# Create The Supabase Project

Use this checklist while creating the YO Health & Fitness backend.

## 1. Create Account

Go to:

```text
https://supabase.com/dashboard
```

Sign in or create a Supabase account.

## 2. Create Organization

If Supabase asks for an organization, create one:

```text
YO Health & Fitness
```

## 3. Create Project

Click:

```text
New project
```

Use:

```text
Project name: yo-health-fitness
Database password: create a strong password and save it privately
Region: closest available region to UAE
Pricing: Free plan is fine for MVP/demo
```

Wait for the project to finish provisioning.

## 4. Copy API Values

In the Supabase dashboard, open:

```text
Project Settings -> API
```

Copy:

```text
Project URL
Publishable key
```

If your dashboard shows legacy keys, copy:

```text
Project URL
anon public key
```

## 5. Send Values To The App

Create a local `.env` file inside:

```text
outputs/yo-health-fitness-react
```

Add:

```text
VITE_SUPABASE_URL=your-project-url
VITE_SUPABASE_PUBLISHABLE_KEY=your-publishable-key
```

Do not put secret/service role keys in the frontend app.

## 6. Run Database Setup

Open:

```text
SQL Editor
```

Run these files in order:

```text
docs/supabase-schema.sql
docs/seed-data.sql
```

## 7. Create Demo Users

Open:

```text
Authentication -> Users
```

Create:

```text
demo@yohealthfitness.com
admin@yohealthfitness.com
```

Then run:

```sql
update public.profiles
set role = 'admin'
where email = 'admin@yohealthfitness.com';
```

## 8. Test

Restart the app:

```bash
pnpm dev
```

Log in with the users you created. The app should show:

```text
Live Supabase mode
```

