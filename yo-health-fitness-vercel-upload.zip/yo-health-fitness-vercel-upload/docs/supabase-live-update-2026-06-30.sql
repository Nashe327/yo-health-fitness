-- YO Health & Fitness live Supabase update.
-- Run this in Supabase SQL Editor to add the newer MVP tables/features.
-- It is designed to be safe to re-run.

create extension if not exists "pgcrypto";

do $$
begin
  create type public.user_role as enum ('client', 'provider', 'corporate', 'admin');
exception
  when duplicate_object then null;
end
$$;

do $$
begin
  alter type public.user_role add value if not exists 'corporate';
end
$$;

do $$
begin
  create type public.payment_status as enum ('unpaid', 'pending', 'paid', 'failed', 'refunded');
exception
  when duplicate_object then null;
end
$$;

do $$
begin
  create type public.availability_status as enum ('open', 'booked', 'blocked');
exception
  when duplicate_object then null;
end
$$;

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles
    where id = auth.uid()
      and role = 'admin'
  );
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    case
      when new.raw_user_meta_data->>'role' in ('client', 'provider', 'corporate', 'admin')
        then (new.raw_user_meta_data->>'role')::public.user_role
      else 'client'::public.user_role
    end
  )
  on conflict (id) do update set
    email = excluded.email,
    full_name = excluded.full_name,
    role = excluded.role;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.bookings
  add column if not exists payment_status public.payment_status not null default 'unpaid';

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings(id) on delete cascade,
  amount_aed integer not null,
  platform_fee_aed integer not null default 0,
  provider_payout_aed integer not null default 0,
  method text not null default 'Hosted checkout',
  status public.payment_status not null default 'pending',
  reference text unique,
  external_checkout_url text,
  created_at timestamptz not null default now()
);

alter table public.payments
  add column if not exists external_payment_id text,
  add column if not exists external_provider text,
  add column if not exists external_checkout_url text;

create table if not exists public.payment_events (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid references public.payments(id) on delete cascade,
  provider text not null,
  event_type text not null,
  external_event_id text,
  payload jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.provider_availability (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.providers(id) on delete cascade,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  location_type text,
  service text,
  status public.availability_status not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists public.provider_documents (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.providers(id) on delete cascade,
  document_type text not null,
  file_url text not null,
  status text not null default 'pending',
  notes text,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.provider_reviews (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.providers(id) on delete cascade,
  booking_id uuid references public.bookings(id) on delete set null,
  client_id uuid references public.profiles(id) on delete set null,
  client_name text,
  rating integer not null check (rating between 1 and 5),
  comment text not null,
  status text not null default 'pending',
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.corporate_employees (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  full_name text not null,
  department text,
  wellness_score integer not null default 75,
  challenge_status text not null default 'invited',
  created_at timestamptz not null default now()
);

create table if not exists public.corporate_challenges (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  name text not null,
  start_date date,
  duration_weeks integer not null default 6,
  target text,
  prize text,
  status text not null default 'scheduled',
  created_at timestamptz not null default now()
);

create table if not exists public.corporate_screenings (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  screening_type text not null,
  screening_date date,
  employees integer not null default 0,
  status text not null default 'requested',
  created_at timestamptz not null default now()
);

create table if not exists public.consent_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  user_email text,
  consent_type text not null,
  version text not null,
  accepted boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.account_deletion_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  user_email text,
  reason text,
  status text not null default 'requested',
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  audience text not null default 'clients',
  title text not null,
  body text,
  status text not null default 'sent',
  created_at timestamptz not null default now()
);

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  user_email text,
  category text not null default 'general',
  subject text not null,
  message text,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists public.pilot_validation_kpis (
  id text primary key,
  kpi_group text not null,
  label text not null,
  target integer not null default 0,
  actual integer not null default 0,
  note text,
  sort_order integer not null default 0,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.pilot_leads (
  id uuid primary key default gen_random_uuid(),
  segment text not null,
  name text,
  company text,
  area text,
  service text,
  stage text not null default 'New',
  next_action text,
  interest integer not null default 3 check (interest between 1 and 5),
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.waitlist_signups (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  full_name text,
  email text not null,
  segment text not null default 'Client',
  city text,
  goal text,
  budget text,
  message text,
  status text not null default 'New',
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

alter table public.payments enable row level security;
alter table public.payment_events enable row level security;
alter table public.provider_availability enable row level security;
alter table public.provider_documents enable row level security;
alter table public.provider_reviews enable row level security;
alter table public.corporate_employees enable row level security;
alter table public.corporate_challenges enable row level security;
alter table public.corporate_screenings enable row level security;
alter table public.consent_records enable row level security;
alter table public.account_deletion_requests enable row level security;
alter table public.notifications enable row level security;
alter table public.support_tickets enable row level security;
alter table public.pilot_validation_kpis enable row level security;
alter table public.pilot_leads enable row level security;
alter table public.waitlist_signups enable row level security;

drop policy if exists "Users can read own payments" on public.payments;
drop policy if exists "Users can create own payments" on public.payments;
drop policy if exists "Admins can manage payments" on public.payments;
drop policy if exists "Providers can read assigned payments" on public.payments;
drop policy if exists "Admins can manage payment events" on public.payment_events;
drop policy if exists "Public can read open provider availability" on public.provider_availability;
drop policy if exists "Providers can manage own availability" on public.provider_availability;
drop policy if exists "Admins can manage provider availability" on public.provider_availability;
drop policy if exists "Providers can manage own documents" on public.provider_documents;
drop policy if exists "Admins can manage provider documents" on public.provider_documents;
drop policy if exists "Public can read approved provider reviews" on public.provider_reviews;
drop policy if exists "Users can create own provider reviews" on public.provider_reviews;
drop policy if exists "Admins can manage provider reviews" on public.provider_reviews;
drop policy if exists "Admins can manage corporate employees" on public.corporate_employees;
drop policy if exists "Admins can manage corporate challenges" on public.corporate_challenges;
drop policy if exists "Admins can manage corporate screenings" on public.corporate_screenings;
drop policy if exists "Users can create own consent records" on public.consent_records;
drop policy if exists "Users can read own consent records" on public.consent_records;
drop policy if exists "Admins can read consent records" on public.consent_records;
drop policy if exists "Users can create deletion requests" on public.account_deletion_requests;
drop policy if exists "Users can read own deletion requests" on public.account_deletion_requests;
drop policy if exists "Admins can manage deletion requests" on public.account_deletion_requests;
drop policy if exists "Admins can manage notifications" on public.notifications;
drop policy if exists "Users can read own notifications" on public.notifications;
drop policy if exists "Users can create support tickets" on public.support_tickets;
drop policy if exists "Users can read own support tickets" on public.support_tickets;
drop policy if exists "Admins can manage support tickets" on public.support_tickets;
drop policy if exists "Admins can manage pilot validation KPIs" on public.pilot_validation_kpis;
drop policy if exists "Admins can manage pilot leads" on public.pilot_leads;
drop policy if exists "Users can create waitlist signups" on public.waitlist_signups;
drop policy if exists "Users can read own waitlist signups" on public.waitlist_signups;
drop policy if exists "Admins can manage waitlist signups" on public.waitlist_signups;

create policy "Users can read own payments" on public.payments
  for select using (
    exists (
      select 1 from public.bookings
      where bookings.id = payments.booking_id
        and bookings.client_id = auth.uid()
    )
  );

create policy "Users can create own payments" on public.payments
  for insert with check (
    exists (
      select 1 from public.bookings
      where bookings.id = payments.booking_id
        and bookings.client_id = auth.uid()
    )
  );

create policy "Admins can manage payments" on public.payments
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Providers can read assigned payments" on public.payments
  for select using (
    exists (
      select 1
      from public.bookings
      join public.providers on providers.id = bookings.provider_id
      where bookings.id = payments.booking_id
        and providers.owner_id = auth.uid()
    )
  );

create policy "Admins can manage payment events" on public.payment_events
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Public can read open provider availability" on public.provider_availability
  for select using (
    status = 'open'
    and exists (
      select 1 from public.providers
      where providers.id = provider_availability.provider_id
        and providers.status = 'verified'
    )
  );

create policy "Providers can manage own availability" on public.provider_availability
  for all using (
    exists (
      select 1 from public.providers
      where providers.id = provider_availability.provider_id
        and providers.owner_id = auth.uid()
    )
  ) with check (
    exists (
      select 1 from public.providers
      where providers.id = provider_availability.provider_id
        and providers.owner_id = auth.uid()
    )
  );

create policy "Admins can manage provider availability" on public.provider_availability
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Providers can manage own documents" on public.provider_documents
  for all using (
    exists (
      select 1 from public.providers
      where providers.id = provider_documents.provider_id
        and providers.owner_id = auth.uid()
    )
  ) with check (
    exists (
      select 1 from public.providers
      where providers.id = provider_documents.provider_id
        and providers.owner_id = auth.uid()
    )
  );

create policy "Admins can manage provider documents" on public.provider_documents
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Public can read approved provider reviews" on public.provider_reviews
  for select using (status = 'approved');

create policy "Users can create own provider reviews" on public.provider_reviews
  for insert with check (client_id = auth.uid() or client_id is null);

create policy "Admins can manage provider reviews" on public.provider_reviews
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage corporate employees" on public.corporate_employees
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage corporate challenges" on public.corporate_challenges
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage corporate screenings" on public.corporate_screenings
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Users can create own consent records" on public.consent_records
  for insert with check (user_id = auth.uid() or user_id is null);

create policy "Users can read own consent records" on public.consent_records
  for select using (user_id = auth.uid());

create policy "Admins can read consent records" on public.consent_records
  for select using (public.is_admin());

create policy "Users can create deletion requests" on public.account_deletion_requests
  for insert with check (user_id = auth.uid() or user_id is null);

create policy "Users can read own deletion requests" on public.account_deletion_requests
  for select using (user_id = auth.uid());

create policy "Admins can manage deletion requests" on public.account_deletion_requests
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage notifications" on public.notifications
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Users can read own notifications" on public.notifications
  for select using (user_id = auth.uid() or user_id is null);

create policy "Users can create support tickets" on public.support_tickets
  for insert with check (user_id = auth.uid() or user_id is null);

create policy "Users can read own support tickets" on public.support_tickets
  for select using (user_id = auth.uid());

create policy "Admins can manage support tickets" on public.support_tickets
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage pilot validation KPIs" on public.pilot_validation_kpis
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage pilot leads" on public.pilot_leads
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Users can create waitlist signups" on public.waitlist_signups
  for insert with check (user_id = auth.uid() or user_id is null);

create policy "Users can read own waitlist signups" on public.waitlist_signups
  for select using (user_id = auth.uid());

create policy "Admins can manage waitlist signups" on public.waitlist_signups
  for all using (public.is_admin()) with check (public.is_admin());

insert into public.pilot_validation_kpis (id, kpi_group, label, target, actual, note, sort_order)
values
  ('provider-talks', 'Supply', 'Provider conversations', 20, 6, 'Trainers, instructors, coaches, wellness providers', 10),
  ('provider-list', 'Supply', 'Providers willing to list', 10, 3, 'Written confirmation preferred', 20),
  ('partner-talks', 'Partners', 'Gym or clinic conversations', 5, 2, 'Gyms, studios, clinics, recovery partners', 30),
  ('partner-proof', 'Partners', 'Partner interest confirmations', 3, 1, 'Email, LOI, or pilot request', 40),
  ('client-interviews', 'Demand', 'Client interviews', 10, 4, 'Budget, pain point, booking preference', 50),
  ('waitlist', 'Demand', 'Waitlist signups', 20, 8, 'Form, message, or spreadsheet entry', 60),
  ('booking-requests', 'Demand', 'Manual booking requests', 5, 1, 'Offline bookings still count as validation', 70),
  ('corporate-calls', 'Corporate', 'Corporate decision-maker calls', 3, 1, 'HR, founder, office manager, people ops', 80),
  ('buyer-demos', 'Buyers', 'Strategic buyer demo requests', 5, 1, 'Buyer asks to see the app', 90)
on conflict (id) do update set
  kpi_group = excluded.kpi_group,
  label = excluded.label,
  target = excluded.target,
  note = excluded.note,
  sort_order = excluded.sort_order,
  updated_at = now();

insert into public.pilot_leads (segment, name, company, area, service, stage, next_action, interest)
select *
from (
  values
    ('Provider', 'Maya Haddad', 'Independent PT', 'Dubai Marina', 'Personal training', 'Verification', 'Collect certificate and available slots', 5),
    ('Gym or Studio', 'Studio Manager', 'Boutique Pilates Studio', 'Jumeirah', 'Pilates classes', 'Demo booked', 'Send pilot listing proposal', 4),
    ('Clinic', 'Operations Lead', 'Recovery clinic group', 'Business Bay', 'Physio and recovery', 'Interested', 'Confirm compliance requirements', 4),
    ('Corporate', 'People Ops', 'Dubai Tech Group', 'DIFC', '30-day wellness pilot', 'Proposal sent', 'Follow up on pilot scope', 3),
    ('Strategic Buyer', 'Partnerships', 'UAE gym chain', 'UAE', 'Marketplace acquisition', 'Research', 'Find digital growth contact', 3)
) as seed(segment, name, company, area, service, stage, next_action, interest)
where not exists (
  select 1 from public.pilot_leads existing
  where existing.company = seed.company
    and existing.segment = seed.segment
);

insert into public.waitlist_signups (full_name, email, segment, city, goal, budget, message, status)
select *
from (
  values
    ('Noura A.', 'noura@example.com', 'Client', 'Dubai Marina', 'Weight loss', 'Premium', 'Interested in a verified home trainer.', 'New'),
    ('HR Team', 'hr@example.com', 'Corporate', 'DIFC', 'Employee wellness', 'Corporate', 'Would like a 30-day steps challenge proposal.', 'Contacted'),
    ('Studio Partner', 'studio@example.com', 'Gym or Studio', 'Jumeirah', 'Featured listing', 'Partner', 'Open to a pilot listing.', 'Qualified')
) as seed(full_name, email, segment, city, goal, budget, message, status)
where not exists (
  select 1 from public.waitlist_signups existing
  where existing.email = seed.email
);
