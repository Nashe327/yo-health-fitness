# Mobile QA Plan

Date: 2026-06-30

Use this checklist before submitting YO Health & Fitness to TestFlight, App Store review, Google Play internal testing, or a buyer demo.

## Device Matrix

Test at minimum:

- iPhone SE or similarly narrow screen.
- iPhone 15/16 size.
- iPad or tablet layout if tablet support is enabled.
- Small Android phone.
- Large Android phone.
- Android tablet if tablet support is enabled.

## Core Flows

- Login screen loads and demo login works.
- Dashboard cards fit without text overlap.
- Health metric form submits and updates dashboard.
- Marketplace filters work.
- Provider detail opens and closes.
- Booking flow creates a booking confirmation.
- Checkout record can be created from booking confirmation.
- Gym search works.
- AI coach screen displays recommendations without medical overclaiming.
- Concierge request content is visible.
- Corporate employee, challenge, and screening forms submit.
- Provider listing editor saves.
- Provider availability publishes slots.
- Provider verification document submission works.
- Admin provider status changes work.
- Admin document review status changes work.
- Trust Center consent and deletion request flows work.
- Launch tab renders checklist, notifications, support tickets, and business tracker.

## Mobile UX Checks

- Bottom/safe-area spacing works on iOS and Android.
- Sidebar/navigation remains usable on small screens.
- Forms do not hide behind keyboard.
- Buttons are large enough for touch.
- Text does not overflow buttons, cards, tables, or modals.
- Provider detail drawer is scrollable.
- No horizontal scrolling unless intentionally designed.
- Images and icons load on cellular-quality network.

## Native Checks

- App icon appears correctly.
- Splash screen appears correctly.
- Status bar color and text contrast are readable.
- App resumes from background without blank screen.
- Deep reload does not break routing.
- Android back button closes dialogs before exiting app.
- No native permission prompt appears unless a feature needs it.

## Store Readiness

- Privacy policy URL is live.
- Terms URL is live.
- Support email is live.
- Health disclaimer is visible.
- Demo account is available.
- Screenshots are current.
- App category and age rating are correct.
- App Store privacy labels and Google Play Data Safety form match actual data collection.

## Release Decision

Do not submit public builds until these are complete:

- Real payment provider integration or payment feature disabled for public review.
- Production Supabase project with audited RLS policies.
- Lawyer-reviewed legal documents.
- Provider verification process documented.
- Real-device QA pass recorded.
