# Firebase Alternative

Supabase is the recommended backend for this project because the marketplace needs relational data: users, providers, gyms, bookings, health metrics, payments, and corporate accounts.

Firebase is still possible if you prefer Google tooling.

## Firebase Services

- Firebase Auth for login
- Firestore for providers, bookings, gyms, and metrics
- Cloud Storage for provider certificates and images
- Cloud Functions for payments, AI coaching, notifications, and admin automation
- Firebase Cloud Messaging for push notifications
- Google Analytics for product metrics

## Firestore Collections

- `users`
- `providers`
- `gyms`
- `bookings`
- `healthMetrics`
- `corporateAccounts`
- `providerApplications`
- `payments`
- `reviews`

## When To Choose Firebase

Choose Firebase if the team is more comfortable with Google products, mobile analytics, and serverless functions.

Choose Supabase if you want SQL, easier reporting, cleaner admin queries, and stronger marketplace-style relational modeling.

