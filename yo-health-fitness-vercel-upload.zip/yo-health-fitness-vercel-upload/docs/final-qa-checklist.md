# Final QA Checklist

Run this before recording a demo or sending the app to a buyer.

## Environment

- Confirm `.env` contains the Supabase URL and publishable key.
- Run the latest `docs/supabase-repair-and-seed.sql` in Supabase.
- Confirm the app opens at `http://127.0.0.1:5180/`.
- Confirm production build passes with `vite build`.
- Confirm Android sync passes with `cap sync android`.

## Demo Flow

1. Dashboard opens without blank screen or console errors.
2. Log a health metric and confirm it appears in dashboard metrics.
3. Open Marketplace, filter providers, open a provider profile.
4. Choose availability, exact time, location, and notes.
5. Request booking and confirm booking confirmation appears.
6. Create hosted checkout record and confirm payment reference appears.
7. Open Provider tab and confirm bookings, payouts, availability, and listing editor show.
8. Publish a provider availability slot.
9. Open Corporate tab and add employee, launch challenge, request screening.
10. Open Trust tab and create consent/deletion records.
11. Open Sell tab and confirm valuation, pitch, CRM, and checklist work.
12. Open Admin tab and confirm bookings, payments, provider approvals display.

## Mobile Checks

- Bottom navigation does not cover content.
- Provider drawer scrolls correctly.
- Forms fit on phone width.
- Buttons remain readable and tappable.
- No horizontal page overflow.

## Buyer Demo Safety

- Do not show private Supabase keys.
- Do not show source code before NDA or written offer.
- Use preview/demo data unless buyer is under diligence.
- State clearly that legal drafts require lawyer review.
- State clearly that AI wellness advice is not medical advice.
