# Supabase Production Hardening

Date: 2026-07-06

Use this before launching YO Health & Fitness publicly or handing the project to a buyer for technical diligence.

## Status

- Schema includes client, provider, corporate, and admin roles.
- RLS is enabled on all app tables.
- Public reads are limited to verified providers, gyms, open availability, and approved reviews.
- Admin-only operations are protected by `public.is_admin()`.
- Demo access can be disabled in the app with `VITE_ENABLE_DEMO_ACCESS=false`.

## Must Run

Fresh production project:

```sql
-- Run the full schema:
docs/supabase-schema.sql
```

Existing project:

```sql
-- Run the latest live update:
docs/supabase-live-update-2026-06-30.sql
```

Repair path:

```sql
-- Use if setup partially failed:
docs/supabase-repair-and-seed.sql
```

## Role Setup

Create real accounts, then assign roles in `public.profiles.role`:

- `client`
- `provider`
- `corporate`
- `admin`

Only a trusted owner should manually assign `admin`. Do not let public signup create admin users in production.

## RLS Verification Checklist

Confirm these in Supabase Table Editor or SQL Editor:

- `profiles`: users can read/update only their own profile; admins can read all.
- `providers`: public can read only `verified`; providers can manage only their own listing; admins can manage all.
- `provider_documents`: provider owner and admins only.
- `provider_reviews`: public reads only `approved`; users create pending reviews; admins moderate.
- `bookings`: clients read/create own bookings; provider owners read assigned bookings; admins manage all.
- `payments`: clients and assigned provider owners can read relevant payment records; admins manage all.
- `health_metrics`: users read/insert own metrics; admins can read all.
- `consent_records`: users create/read own records; admins can read all.
- `account_deletion_requests`: users create/read own requests; admins manage.
- `notifications`: admins manage; users read their own or broadcast notifications.
- `support_tickets`: users create/read own tickets; admins manage.

## Production Data Rules

- Never commit service role keys.
- Never store raw card data.
- Never store real provider ID documents in demo databases.
- Keep provider document links private or move them to Supabase Storage with signed URLs before public launch.
- Keep AI/health advice framed as wellness support, not diagnosis or treatment.

## Admin Account Creation

1. Sign up with the real founder/admin email.
2. In Supabase SQL Editor, run:

```sql
update public.profiles
set role = 'admin'
where email = 'founder@example.com';
```

3. Log out and back in.
4. Confirm Admin tab appears only for admin users.

## Reviewer Accounts

Create limited review accounts:

- `review-client@yourdomain.com` with role `client`
- `review-provider@yourdomain.com` with role `provider`
- `review-corporate@yourdomain.com` with role `corporate`

Avoid giving app reviewers unrestricted admin access unless they specifically need to inspect admin workflows.

## Remaining Backend Work Before Scale

- Add Supabase Storage buckets for provider documents.
- Add signed URL flow for private document viewing.
- Add server-side payment webhook verification.
- Add audit log table for admin moderation actions.
- Add rate limiting or abuse controls for support tickets and reviews.
