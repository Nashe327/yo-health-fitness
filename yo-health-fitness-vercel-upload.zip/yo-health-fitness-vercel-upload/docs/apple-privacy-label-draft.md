# Apple App Privacy Label Draft

Date: 2026-07-06

Use this as the draft for App Store Connect. Verify against the final production build, privacy policy, SDK list, analytics setup, payment provider, and legal review before submission.

Apple requires developers to disclose data collected by the app and third-party partners. Official reference: https://developer.apple.com/app-store/app-privacy-details/

## Tracking

Current MVP answer: No tracking.

Do not enable ad SDKs, retargeting, data broker sharing, or cross-app tracking unless the privacy label and consent flows are updated.

## Data Linked To User

Likely yes. The app uses accounts and stores records linked to a user profile.

## Data Categories To Disclose

### Contact Info

Collected:

- Name
- Email address
- Phone number, if user adds it

Purpose:

- App functionality
- Account management
- Customer support
- Provider/client coordination

Linked to user: Yes.

### Health And Fitness

Collected:

- Goals
- Body metrics
- Health metrics
- Fitness metrics
- Sleep/stress/recovery data entered by user

Purpose:

- App functionality
- Product personalization
- Wellness dashboard

Linked to user: Yes.

### Purchases / Payment Records

Collected by app:

- Booking payment amount
- Payment status
- Provider payout
- Platform fee
- Payment reference
- Hosted checkout link

Not collected by app:

- Raw card number
- Card security code
- Bank account details

Purpose:

- App functionality
- Payment reconciliation
- Fraud/safety operations

Linked to user: Yes.

### User Content

Collected:

- Booking notes
- Provider reviews
- Support ticket messages
- Account deletion request reason
- Provider verification notes

Purpose:

- App functionality
- Customer support
- Trust and safety

Linked to user: Yes.

### Identifiers

Collected:

- Supabase user ID
- Internal account ID
- Booking/payment IDs

Purpose:

- App functionality
- Security
- Account management

Linked to user: Yes.

### Usage Data

Current MVP:

- No separate analytics SDK is currently documented.

If analytics is added later, disclose product interaction and diagnostics as appropriate.

### Diagnostics

Current MVP:

- No crash reporting SDK is currently documented.

If Sentry, Firebase Crashlytics, or similar is added later, disclose crash/performance data.

## Sensitive Data Warning

Health/wellness data and provider identity documents are sensitive. Legal and privacy review should confirm exact App Store Connect answers before public launch.

## Privacy URLs

Required before submission:

- Public privacy policy URL.
- Optional privacy choices/account deletion URL.
