-- YO Health & Fitness demo activity seed.
-- Run this after providers, gyms, and at least one profile/user exist.
-- It attaches sample bookings and health metrics to the first profile in your database.

with demo_client as (
  select id
  from public.profiles
  order by created_at asc
  limit 1
),
maya as (
  select id
  from public.providers
  where name = 'Maya Haddad'
  limit 1
),
nadine as (
  select id
  from public.providers
  where name = 'Nadine Rossi'
  limit 1
)
insert into public.bookings (client_id, provider_id, service, booking_time, location_type, status, value_aed, notes)
select demo_client.id, maya.id, 'Strength assessment', now() + interval '1 day', 'Home visit', 'requested', 380, 'Demo booking from YO Health & Fitness'
from demo_client, maya
where not exists (
  select 1 from public.bookings
  where service = 'Strength assessment'
    and provider_id = maya.id
    and client_id = demo_client.id
)
union all
select demo_client.id, nadine.id, 'Stress reset yoga', now() + interval '3 days', 'Hotel', 'confirmed', 340, 'Demo concierge-style wellness session'
from demo_client, nadine
where not exists (
  select 1 from public.bookings
  where service = 'Stress reset yoga'
    and provider_id = nadine.id
    and client_id = demo_client.id
);

with demo_client as (
  select id
  from public.profiles
  order by created_at asc
  limit 1
),
metrics(metric_key, metric_value, metric_unit) as (
  values
    ('weight', 84.2, 'kg'),
    ('bmi', 27.1, 'score'),
    ('body_fat', 24.1, 'percent'),
    ('lean_muscle_mass', 60.9, 'kg'),
    ('resting_heart_rate', 58, 'bpm'),
    ('sleep_quality', 72, 'score'),
    ('stress_level', 54, 'score'),
    ('vo2_max', 43, 'score')
)
insert into public.health_metrics (client_id, metric_key, metric_value, metric_unit, recorded_at)
select demo_client.id, metrics.metric_key, metrics.metric_value, metrics.metric_unit, now()
from demo_client, metrics
where not exists (
  select 1 from public.health_metrics
  where client_id = demo_client.id
    and metric_key = metrics.metric_key
);
