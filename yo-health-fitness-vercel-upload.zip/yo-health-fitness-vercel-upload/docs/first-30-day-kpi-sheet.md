# First 30-Day KPI Sheet

Use this as the weekly scorecard while validating YO Health & Fitness.

## Supply KPIs

| KPI | Target | Actual | Status | Notes |
|---|---:|---:|---|---|
| Provider conversations | 20 | 0 | Not started | Trainers, instructors, coaches, wellness providers |
| Providers willing to list | 10 | 0 | Not started | Written confirmation preferred |
| Complete provider profiles | 5 | 0 | Not started | Price, location, services, availability, credentials |
| Provider documents collected | 5 | 0 | Not started | IDs, certifications, trade license where applicable |
| Provider commission accepted | 5 | 0 | Not started | Track acceptable commission or subscription model |

## Partner KPIs

| KPI | Target | Actual | Status | Notes |
|---|---:|---:|---|---|
| Gym or studio conversations | 5 | 0 | Not started | Include boutique studios |
| Clinic or recovery conversations | 3 | 0 | Not started | Subject to licensing review |
| Partner interest confirmations | 3 | 0 | Not started | Email or signed LOI |
| Featured listing interest | 2 | 0 | Not started | Tests advertising revenue |

## Demand KPIs

| KPI | Target | Actual | Status | Notes |
|---|---:|---:|---|---|
| Client interviews | 10 | 0 | Not started | Ask about budgets and pain points |
| Waitlist signups | 20 | 0 | Not started | Use a form or spreadsheet |
| Booking requests | 5 | 0 | Not started | Manual booking requests count |
| Paid test bookings | 2 | 0 | Not started | Offline payment is acceptable for validation |
| Repeat booking intent | 30% | 0% | Not started | Ask after session |

## Corporate KPIs

| KPI | Target | Actual | Status | Notes |
|---|---:|---:|---|---|
| Corporate decision maker conversations | 3 | 0 | Not started | HR, founder, operations, office manager |
| Pilot proposals sent | 1 | 0 | Not started | Use corporate pilot proposal |
| Corporate pilot interest | 1 | 0 | Not started | Written reply preferred |

## Buyer KPIs

| KPI | Target | Actual | Status | Notes |
|---|---:|---:|---|---|
| Strategic buyer messages sent | 25 | 0 | Not started | Gyms, clinics, brands, wellness companies |
| Demo requests | 5 | 0 | Not started | Buyer asks to see app |
| Serious buyer conversations | 2 | 0 | Not started | NDA, terms, or handoff discussion |
| Written offer or partnership discussion | 1 | 0 | Not started | Even early interest is useful |

## Weekly Review Questions

- Which customer group showed the strongest pull?
- Which service category was requested most?
- Which objection appeared most often?
- Did anyone ask to pay, pilot, list, or buy?
- What should be removed, simplified, or delayed?
- Is the strongest path selling, partnering, or launching lean?
