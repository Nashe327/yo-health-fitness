# Source Code Release Rules

Use these rules when speaking with buyers.

## Before NDA

Share:

- Demo video.
- Screenshots.
- Product memo.
- Sales handoff memo.
- Guided live demo.
- High-level architecture.

Do not share:

- Full source code.
- Supabase project access.
- Private keys.
- Git repository write access.
- Local `.env` file.

## After NDA

Share:

- Read-only repository access.
- Architecture walkthrough.
- Supabase schema without secrets.
- Build instructions.
- Known limitations and roadmap.

## After Written Offer Or Paid Diligence

Share:

- Full technical diligence package.
- Android project.
- Deployment walkthrough.
- Detailed backlog.
- Handoff call with developer.

## Always Remove

- Secret keys.
- Personal credentials.
- Private Supabase service role keys.
- Personal notes not intended for buyer.
