# Supabase Setup

## 1. Create Project

Create a Supabase project and copy:

- Project URL
- Publishable key

## 2. Add Environment Variables

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Fill in:

```text
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your-publishable-key
```

Legacy Supabase projects may show an `anon` key instead. The app supports that too:

```text
VITE_SUPABASE_ANON_KEY=your-anon-key
```

## 3. Run SQL

Open Supabase SQL Editor and run:

1. `docs/supabase-schema.sql`
2. `docs/seed-data.sql`

## 4. Create Demo Users

In Supabase Authentication, create:

```text
demo@yohealthfitness.com
admin@yohealthfitness.com
```

Then update the admin profile role:

```sql
update public.profiles
set role = 'admin'
where email = 'admin@yohealthfitness.com';
```

## 5. Run The App

```bash
pnpm dev
```

The top-left status changes from `Demo mode` to `Live Supabase mode`.

## 6. What Works After Connection

- Real email/password auth
- Sign up
- Profile creation
- Provider list from database
- Gym list from database
- Booking creation in database
- Booking list from database
- Admin booking status updates
