# Store Screenshot Plan

Date: 2026-07-06

Capture screenshots after final mobile QA and before App Store / Google Play submission.

## Required Devices

Minimum screenshot set:

- iPhone 6.7-inch display.
- iPhone 6.1-inch or 5.5-inch display, depending current App Store Connect requirements.
- Android phone, common 1080 x 1920 or 1080 x 2400 format.
- Optional Android tablet if tablet support is enabled.
- Optional iPad if iPad support is enabled.

## Screenshot Sequence

Use consistent demo data and production-safe wording.

1. Client dashboard
   - Show wellness dashboard, metrics, and next booking.
   - Caption idea: `Your health and fitness command center`

2. Provider marketplace
   - Show provider cards, filters, verified badges, ratings.
   - Caption idea: `Book trusted trainers and wellness experts`

3. Provider profile and booking
   - Show provider detail, reviews, available slots, session price.
   - Caption idea: `Choose services, time, and location`

4. Booking confirmation and hosted checkout
   - Show booking summary, platform fee, provider payout, hosted checkout note.
   - Caption idea: `Secure hosted checkout, no card data stored`

5. AI coach / transformation engine
   - Show AI recommendations but avoid medical claims.
   - Caption idea: `Wellness guidance that adapts to your signals`

6. Corporate wellness
   - Show challenges, employees, screenings, executive report.
   - Caption idea: `Corporate wellness programs for teams`

7. Provider portal
   - Show availability, documents, booking queue, payout ledger.
   - Caption idea: `Tools for providers to manage bookings`

8. Trust center
   - Show privacy, terms, disclaimer, consent, deletion request.
   - Caption idea: `Privacy, consent, and account controls`

## Screens To Avoid In Public Store Screenshots

- Admin dashboard with sensitive operational data.
- Buyer/sales/deal room screens.
- Any real provider identity document.
- Any real user health data.
- Any claim implying diagnosis, treatment, guaranteed weight loss, or medical advice.

## Capture Checklist

- Use `VITE_ENABLE_DEMO_ACCESS=false` for production screenshots unless reviewer demo access is intentionally shown.
- Use fake/demo user data only.
- Confirm text does not overlap on mobile.
- Confirm bottom navigation is visible and not covering primary actions.
- Confirm Health Disclaimer is available from Trust Center.
- Confirm account deletion request is visible.
- Confirm hosted checkout wording says no raw card data is stored.
