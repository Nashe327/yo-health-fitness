# Role Protection Checklist

Date: 2026-07-06

This checklist covers the first production-hardening step: separating demo access from public app access and making user roles intentional.

## App Controls

- `VITE_ENABLE_DEMO_ACCESS=true` keeps preview/demo role switching available for buyer demos and internal QA.
- `VITE_ENABLE_DEMO_ACCESS=false` hides preview access and admin demo shortcuts for public App Store / Play Store builds.
- Client, provider, corporate, and admin roles each receive their own navigation workspace.
- If a user tries to access a screen outside their role, the app routes them back to their role home.

## Production Build Setting

For public mobile builds, set:

```text
VITE_ENABLE_DEMO_ACCESS=false
```

Keep demo access enabled only for:

- internal QA
- guided buyer demos
- app review accounts when explicitly needed
- investor walkthroughs

## Supabase Role Setup

Create real accounts and assign roles in `profiles.role`:

- `client`
- `provider`
- `corporate`
- `admin`

Admin accounts should be manually approved by the founder or technical owner. Do not allow public users to self-select admin in production.

## Remaining Hardening

- Audit all Supabase RLS policies before launch.
- Create a limited App Store reviewer account.
- Create a limited Google Play reviewer account.
- Remove real personal data from demo builds.
- Add server-side checks before sensitive admin actions if moving beyond MVP.
