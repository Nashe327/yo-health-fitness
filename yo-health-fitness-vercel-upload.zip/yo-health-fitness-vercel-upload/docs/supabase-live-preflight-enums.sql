-- YO Health & Fitness Supabase live update preflight.
-- Run this first on an existing/old Supabase project if the live update fails.
-- After it succeeds, open a new SQL query and run docs/supabase-live-update-2026-06-30.sql.

do $$
begin
  create type public.user_role as enum ('client', 'provider', 'corporate', 'admin');
exception
  when duplicate_object then null;
end
$$;

do $$
begin
  alter type public.user_role add value if not exists 'corporate';
end
$$;

do $$
begin
  create type public.payment_status as enum ('unpaid', 'pending', 'paid', 'failed', 'refunded');
exception
  when duplicate_object then null;
end
$$;

do $$
begin
  create type public.availability_status as enum ('open', 'booked', 'blocked');
exception
  when duplicate_object then null;
end
$$;
