# Live Supabase Update Instructions

Use this when your Supabase project already has the original YO Health & Fitness base tables and you only need to add the newer MVP tables.

If this is a new Supabase project, do not run the live update first. Run the full repair-and-seed file instead:

```text
docs/supabase-repair-and-seed.sql
```

The most common failure is:

```text
relation "public.bookings" does not exist
```

That means the base schema has not been created yet.

## What This Adds

- Booking `payment_status`
- `payments`
- `provider_availability`
- `corporate_employees`
- `corporate_challenges`
- `corporate_screenings`
- `consent_records`
- `account_deletion_requests`
- Row-level security policies for those tables

## Steps

1. Open Supabase.
2. Go to SQL Editor.
3. Open `docs/supabase-live-update-2026-06-30.sql`.
4. Copy the full SQL file.
5. Paste it into Supabase SQL Editor.
6. Click Run.
7. Refresh Table Editor and confirm the new tables appear.

## After Running

Open the app and test:

- Booking checkout record.
- Provider availability slot.
- Corporate employee/challenge/screening.
- Trust consent record.
- Account deletion request.

## If It Fails

If your old project fails with an enum error like this:

```text
unsafe use of new value "corporate" of enum type user_role
```

Run this small preflight file first:

```text
docs/supabase-live-preflight-enums.sql
```

Then open a new SQL query and run the live update again:

```text
docs/supabase-live-update-2026-06-30.sql
```

Use the full repair-and-seed file instead:

```text
docs/supabase-repair-and-seed.sql
```

That file creates/repairs the full MVP schema, security policies, and demo data.
