# MVP Completion Plan

This is the practical path from the current app to a sellable MVP.

## Completed Foundation

- React/Vite app with responsive mobile UI.
- Supabase auth, profiles, providers, gyms, bookings, and health metrics schema.
- Provider marketplace with filters and booking request flow.
- Booking confirmation and commission calculation.
- Provider availability slot selection.
- Hosted checkout preparation with payment records, deposits, platform fees, and provider payouts.
- Provider portal for listing edits, availability publishing, booking queue management, and payout ledger.
- Corporate client portal for employee roster, wellness challenges, health screenings, and executive reports.
- Trust center with privacy, terms, health disclaimer, consent audit log, and account deletion request workflow.
- Sales package workspace with valuation scenario, acquisition pitch, demo run-of-show, buyer CRM, and handoff checklist.
- Editable client profile.
- Health metric logging from the dashboard.
- Gym discovery, AI coach, concierge, corporate wellness, revenue, buyer pipeline, and admin screens.
- Android Capacitor project generated and synced.
- iOS Capacitor configuration ready once Xcode/CocoaPods are installed.
- App icons, manifest, store listing draft, and buyer handoff checklist.

## Next Product Milestones

1. Real Payment Provider
   Replace the current checkout record with a live hosted checkout URL from Stripe, Tap, Checkout.com, or Ziina.

2. Advanced Provider Calendar
   Extend provider availability into recurring slots, blackout dates, Google Calendar sync, and automatic slot booking.

3. Notifications
   Add booking emails first, then mobile push notifications.

4. Corporate Account Permissions
   Add company admin roles, department managers, employee invitations, and aggregate-only privacy controls.

5. Admin Hardening
   Add provider verification documents, admin notes, rejection reasons, and audit history.

6. AI Coaching
   Convert the current simulated plan adjustment into a server-side recommendation engine using stored health metrics and booking history.

7. Legal Review
   Have UAE counsel review the privacy policy, terms, health disclaimer, provider agreements, cancellation policy, refund policy, and corporate wellness data terms.

8. Store Submission
   Complete native QA on physical devices, create screenshots, configure signing, and submit to App Store Connect and Google Play Console.

## Sellable MVP Positioning

The current app can be pitched as a working marketplace MVP with live Supabase backend, mobile packaging, branded Android shell, booking flow, availability selection, checkout records, and a clear roadmap to live payment launch.
