-- YO Health & Fitness simple demo activity seed.
-- Use this if seed-demo-activity.sql fails.
-- This version does not require a profile/user row.

insert into public.bookings (provider_id, service, booking_time, location_type, status, value_aed, notes)
select id, 'Strength assessment', now() + interval '1 day', 'Home visit', 'requested', 380, 'Demo booking: client profile not attached yet'
from public.providers
where name = 'Maya Haddad'
  and not exists (
    select 1 from public.bookings
    where service = 'Strength assessment'
  );

insert into public.bookings (provider_id, service, booking_time, location_type, status, value_aed, notes)
select id, 'Stress reset yoga', now() + interval '3 days', 'Hotel', 'confirmed', 340, 'Demo booking: concierge-style wellness session'
from public.providers
where name = 'Nadine Rossi'
  and not exists (
    select 1 from public.bookings
    where service = 'Stress reset yoga'
  );

insert into public.health_metrics (metric_key, metric_value, metric_unit, recorded_at)
select metric_key, metric_value, metric_unit, now()
from (
  values
    ('weight', 84.2, 'kg'),
    ('bmi', 27.1, 'score'),
    ('body_fat', 24.1, 'percent'),
    ('lean_muscle_mass', 60.9, 'kg'),
    ('resting_heart_rate', 58, 'bpm'),
    ('sleep_quality', 72, 'score'),
    ('stress_level', 54, 'score'),
    ('vo2_max', 43, 'score')
) as metrics(metric_key, metric_value, metric_unit)
where not exists (
  select 1 from public.health_metrics
  where health_metrics.metric_key = metrics.metric_key
);
