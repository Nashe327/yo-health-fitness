# Google Play Data Safety Draft

Date: 2026-07-06

Use this as the draft for the Google Play Console Data Safety form. Verify against the final production build, privacy policy, SDK list, analytics setup, payment provider, and legal review before submission.

Google Play requires developers to disclose data collection, sharing, security practices, and deletion options. Official reference: https://support.google.com/googleplay/android-developer/answer/10787469

## Data Collection

Current MVP answer: Yes, the app collects user data.

## Data Sharing

Current MVP answer: Yes, limited sharing may occur with:

- Supabase/backend infrastructure.
- Hosted payment provider.
- Selected providers for booking fulfillment.
- Corporate administrators where lawful/consented and preferably aggregated.
- Legal/compliance providers where required.

Confirm final answer with counsel and the selected payment provider.

## Security Practices

Draft answers:

- Data encrypted in transit: Yes, production app should use HTTPS/Supabase TLS.
- Users can request data deletion: Yes, Trust Center includes account deletion request flow.
- Independent security review: No, unless a formal third-party review is completed.

## Data Types

### Personal Info

Collected:

- Name
- Email address
- Phone number, if added
- User IDs

Purpose:

- Account management
- App functionality
- Customer support

### Health And Fitness

Collected:

- Wellness goals
- Body metrics
- Health metrics
- Fitness metrics
- Sleep/stress/recovery fields

Purpose:

- App functionality
- Wellness dashboard
- Product personalization

### Financial Info

Collected by app:

- Payment amount
- Payment status
- Hosted checkout reference

Not collected by app:

- Raw card details
- CVV
- Bank account credentials

Purpose:

- Payment processing
- Booking reconciliation
- Fraud/safety operations

### App Activity

Current MVP:

- Search/filter activity may be processed inside the app.
- No separate analytics SDK is documented.

If analytics is added, update this section.

### App Info And Performance

Current MVP:

- No crash reporting SDK is documented.

If Crashlytics, Sentry, or similar is added, disclose crash logs and diagnostics.

### User-Generated Content

Collected:

- Booking notes
- Reviews
- Support ticket messages
- Deletion request text
- Provider profile/listing content

Purpose:

- App functionality
- Trust and safety
- Customer support

## Data Deletion

The Trust Center includes account deletion requests. Before production launch, connect requests to an operational support process and publish a clear deletion URL/email.

## Children

Current launch assumption: not designed for children.

Add age gating or legal review if targeting minors, school programs, or youth sports.

## Notes Before Submission

- Make sure Google Play answers match the public privacy policy.
- Re-check after adding analytics, crash reporting, push notifications, payment SDKs, or file uploads.
- Do not claim no data collection if Supabase auth, bookings, health metrics, reviews, or payments are enabled.
