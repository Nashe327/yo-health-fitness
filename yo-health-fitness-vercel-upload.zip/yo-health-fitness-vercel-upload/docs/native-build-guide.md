# Native Build Guide

YO Health & Fitness is set up as a React/Vite app wrapped with Capacitor. The web app is the product interface; Capacitor packages it into iOS and Android native projects.

## One-Time Machine Setup

Install:

- Node.js 20+
- pnpm
- Xcode from the Mac App Store
- Apple Developer account
- Android Studio
- Google Play Console account

On macOS, also run:

```bash
xcode-select --install
sudo xcode-select --switch /Applications/Xcode.app
```

## Create Native Projects

From this folder:

```bash
pnpm install
pnpm build
pnpm cap:add:ios
pnpm cap:add:android
pnpm cap:sync
```

This creates:

- `ios/` for Xcode
- `android/` for Android Studio

Current project status:

- Android has already been generated in `android/`.
- iOS is ready to generate, but this Mac must have Xcode command line tools and CocoaPods installed first.
- Latest `cap add ios` attempt failed with: `CocoaPods is not installed.`

If `pnpm cap:add:ios` says CocoaPods is missing, install it before retrying:

```bash
brew install cocoapods
pod --version
pnpm cap:add:ios
pnpm cap:sync ios
```

## Repeat Build Flow

After editing React code:

```bash
pnpm mobile:prepare
```

For one platform at a time:

```bash
pnpm mobile:android
pnpm mobile:ios
```

Then open the native projects:

```bash
pnpm cap:open:ios
pnpm cap:open:android
```

## App Identity

- App name: YO Health & Fitness
- iOS bundle ID: `com.yohealthfitness.app`
- Android package: `com.yohealthfitness.app`
- Primary color: `#14231d`
- App icon source: `public/icons/icon-1024.png`

## Native Store Work Still Needed

Before submitting to stores, a developer must:

- Add final native icon sets inside Xcode and Android Studio.
- Configure signing certificates and provisioning profiles.
- Add production Supabase URL and publishable key.
- Add privacy policy, terms, health disclaimer, and support email.
- Complete `docs/app-store-review-notes.md`.
- Run `docs/mobile-qa-plan.md` on real devices.
- Test booking, auth, admin, provider application, and responsive layouts on real devices.
- Submit through App Store Connect and Google Play Console.

## Local Verification Commands

These commands were used to verify the current mobile-ready web build:

```bash
./node_modules/.bin/vite build
./node_modules/.bin/cap add android
./node_modules/.bin/cap sync android
```

The iOS command was attempted, but failed on this machine because CocoaPods is not installed.
