# Demo Recording Shot List

Target length: 90 to 120 seconds.

## Shots

1. Dashboard
   Show YO Health & Fitness as the wellness command center.

2. Health Metric Logging
   Save a metric to prove user data entry works.

3. Provider Marketplace
   Filter providers and open a profile.

4. Booking Flow
   Choose availability, request booking, show confirmation.

5. Checkout Preparation
   Create deposit or full-payment checkout record.

6. Provider Portal
   Show listing editor, booking queue, availability, and payout ledger.

7. Corporate Portal
   Add employee, launch challenge, request screening, show executive report.

8. Trust Center
   Show health disclaimer, privacy, terms, consent, deletion request.

9. Sell Tab
   Show valuation model, pitch, buyer CRM, and handoff checklist.

10. Android Ready
   Mention Android Capacitor project is generated and iOS is ready after Xcode/CocoaPods setup.

## Closing Line

YO Health & Fitness is a working UAE-ready marketplace MVP for health, fitness, wellness, corporate wellness, and premium Dubai concierge services.
