# Legal And Compliance Launch Pack

Date: 2026-07-06

This is a founder and buyer handoff checklist. It is not legal advice. A UAE lawyer, data protection advisor, healthcare compliance advisor, accountant, and payment provider should review the final production setup before public launch.

## Current Legal Drafts

- `docs/legal/privacy-policy-draft.md`
- `docs/legal/terms-of-service-draft.md`
- `docs/legal/health-disclaimer-draft.md`
- `docs/legal/provider-agreement-draft.md`
- `docs/legal/app-store-compliance-notes.md`

## Positioning Decision

Launch YO Health & Fitness first as a wellness marketplace and booking platform, not as a medical provider or medical device.

Safe launch positioning:

- Fitness booking.
- Wellness coaching.
- Gym discovery.
- General wellness dashboard.
- Corporate wellness engagement.
- Hosted checkout marketplace.
- Provider verification and moderated reviews.

Do not publicly launch high-risk medical positioning until reviewed:

- Diagnosis.
- Treatment.
- Disease management.
- Clinical screening interpretation.
- Physiotherapy claims.
- Nutrition therapy claims.
- Injury rehabilitation claims.
- AI medical advice.

## Required Public URLs

Before App Store or Google Play submission:

- Privacy policy URL.
- Terms of service URL.
- Health disclaimer URL or in-app screen.
- Support/contact URL or email.
- Account deletion instructions.

## Lawyer Review Questions

Ask UAE counsel:

- What trade license activities are required for a wellness marketplace and booking platform?
- Can the platform list physiotherapists, nutritionists, massage therapists, and health-screening providers without becoming a regulated healthcare provider?
- What language is required for health disclaimers and provider responsibility?
- What provider verification documents should be collected?
- What insurance requirements should providers meet?
- What consumer cancellation/refund language is needed?
- What dispute-resolution venue should the terms use?
- What data retention and deletion timeline should be used?
- What corporate wellness employee-consent language is required?
- What app-store privacy disclosures are needed for health/wellness data?

## Data Protection Review Questions

Ask privacy/data counsel:

- Which data categories are personal data, sensitive data, or health data?
- What consent or lawful basis is needed for wellness metrics?
- How should corporate wellness reporting avoid exposing individual employee health data?
- What user rights process is required for access, correction, deletion, and withdrawal of consent?
- Should provider identity documents be stored in Supabase Storage with signed URLs?
- What retention periods should apply to bookings, payments, health metrics, support tickets, and provider documents?

## Payment Compliance Questions

Ask the payment provider:

- Can the account support marketplace-style provider payouts?
- Are split payments available or should payouts be handled manually at first?
- What refund, chargeback, and dispute process is required?
- What KYC documents are needed?
- What webhook signature verification is required?
- What payment terms must be disclosed to users?

## App Store Review Risk Areas

Apple and Google may scrutinize:

- Health claims.
- AI claims.
- Account deletion.
- Privacy labels and data safety forms.
- Hosted checkout/payment flow.
- Provider verification and user-generated reviews.
- Medical-adjacent services.
- Corporate wellness employee data.

## Production Launch Gate

Do not publicly launch until:

- Lawyer-reviewed privacy policy is published.
- Lawyer-reviewed terms are published.
- Health disclaimer is visible inside the app.
- Provider agreement is approved.
- Payment provider terms are understood.
- Supabase RLS is audited.
- Demo/admin access is disabled for public builds.
- Provider verification workflow is operational.
- Support email is live.
- Account deletion process is operational.

## Official Starting Points

- UAE data protection laws: https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws
- UAE consumer protection: https://u.ae/en/information-and-services/justice-safety-and-the-law/consumer-protection
- Dubai Health Authority regulations: https://www.dha.gov.ae/en/regulations
- UAE business services: https://u.ae/en/information-and-services/business
