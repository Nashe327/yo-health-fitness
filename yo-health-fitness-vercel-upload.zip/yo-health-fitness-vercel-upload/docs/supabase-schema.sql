-- YO Health & Fitness Supabase starter schema
-- Run this in Supabase SQL Editor after creating a project.

create extension if not exists "pgcrypto";

create type public.user_role as enum ('client', 'provider', 'corporate', 'admin');
create type public.booking_status as enum ('requested', 'confirmed', 'completed', 'cancelled');
create type public.payment_status as enum ('unpaid', 'pending', 'paid', 'failed', 'refunded');
create type public.availability_status as enum ('open', 'booked', 'blocked');
create type public.provider_status as enum ('pending', 'verified', 'rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  full_name text,
  role public.user_role not null default 'client',
  phone text,
  location text,
  goals text[] default '{}',
  created_at timestamptz not null default now()
);

create table public.providers (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references public.profiles(id) on delete set null,
  name text not null,
  role text not null,
  goal text not null,
  location text not null,
  budget text not null,
  rating numeric(2,1) not null default 0,
  price_aed integer not null,
  image_url text,
  tags text[] default '{}',
  status public.provider_status not null default 'pending',
  license_url text,
  created_at timestamptz not null default now()
);

create table public.gyms (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  area text not null,
  monthly_price_aed integer,
  rating numeric(2,1) default 0,
  description text,
  facilities text[] default '{}',
  featured boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.provider_availability (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.providers(id) on delete cascade,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  location_type text,
  service text,
  status public.availability_status not null default 'open',
  created_at timestamptz not null default now()
);

create table public.provider_documents (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.providers(id) on delete cascade,
  document_type text not null,
  file_url text not null,
  status text not null default 'pending',
  notes text,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.profiles(id) on delete set null,
  provider_id uuid references public.providers(id) on delete set null,
  service text not null,
  booking_time timestamptz,
  location_type text,
  status public.booking_status not null default 'requested',
  payment_status public.payment_status not null default 'unpaid',
  value_aed integer not null default 0,
  notes text,
  created_at timestamptz not null default now()
);

create table public.provider_reviews (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.providers(id) on delete cascade,
  booking_id uuid references public.bookings(id) on delete set null,
  client_id uuid references public.profiles(id) on delete set null,
  client_name text,
  rating integer not null check (rating between 1 and 5),
  comment text not null,
  status text not null default 'pending',
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings(id) on delete cascade,
  amount_aed integer not null,
  platform_fee_aed integer not null default 0,
  provider_payout_aed integer not null default 0,
  method text not null default 'Hosted checkout',
  status public.payment_status not null default 'pending',
  reference text unique,
  external_payment_id text,
  external_provider text,
  external_checkout_url text,
  created_at timestamptz not null default now()
);

create table public.payment_events (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid references public.payments(id) on delete cascade,
  provider text not null,
  event_type text not null,
  external_event_id text,
  payload jsonb,
  created_at timestamptz not null default now()
);

create table public.health_metrics (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.profiles(id) on delete cascade,
  metric_key text not null,
  metric_value numeric,
  metric_unit text,
  recorded_at timestamptz not null default now()
);

create table public.corporate_employees (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  full_name text not null,
  department text,
  wellness_score integer not null default 75,
  challenge_status text not null default 'invited',
  created_at timestamptz not null default now()
);

create table public.corporate_challenges (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  name text not null,
  start_date date,
  duration_weeks integer not null default 6,
  target text,
  prize text,
  status text not null default 'scheduled',
  created_at timestamptz not null default now()
);

create table public.corporate_screenings (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  screening_type text not null,
  screening_date date,
  employees integer not null default 0,
  status text not null default 'requested',
  created_at timestamptz not null default now()
);

create table public.consent_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  user_email text,
  consent_type text not null,
  version text not null,
  accepted boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.account_deletion_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  user_email text,
  reason text,
  status text not null default 'requested',
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  audience text not null default 'clients',
  title text not null,
  body text,
  status text not null default 'sent',
  created_at timestamptz not null default now()
);

create table public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  user_email text,
  category text not null default 'general',
  subject text not null,
  message text,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table public.pilot_validation_kpis (
  id text primary key,
  kpi_group text not null,
  label text not null,
  target integer not null default 0,
  actual integer not null default 0,
  note text,
  sort_order integer not null default 0,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table public.pilot_leads (
  id uuid primary key default gen_random_uuid(),
  segment text not null,
  name text,
  company text,
  area text,
  service text,
  stage text not null default 'New',
  next_action text,
  interest integer not null default 3 check (interest between 1 and 5),
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table public.waitlist_signups (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  full_name text,
  email text not null,
  segment text not null default 'Client',
  city text,
  goal text,
  budget text,
  message text,
  status text not null default 'New',
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles
    where id = auth.uid()
      and role = 'admin'
  );
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    case
      when new.raw_user_meta_data->>'role' in ('client', 'provider', 'corporate', 'admin')
        then (new.raw_user_meta_data->>'role')::public.user_role
      else 'client'::public.user_role
    end
  )
  on conflict (id) do update set
    email = excluded.email,
    full_name = excluded.full_name,
    role = excluded.role;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.providers enable row level security;
alter table public.gyms enable row level security;
alter table public.provider_availability enable row level security;
alter table public.provider_documents enable row level security;
alter table public.provider_reviews enable row level security;
alter table public.bookings enable row level security;
alter table public.payments enable row level security;
alter table public.payment_events enable row level security;
alter table public.health_metrics enable row level security;
alter table public.corporate_employees enable row level security;
alter table public.corporate_challenges enable row level security;
alter table public.corporate_screenings enable row level security;
alter table public.consent_records enable row level security;
alter table public.account_deletion_requests enable row level security;
alter table public.notifications enable row level security;
alter table public.support_tickets enable row level security;
alter table public.pilot_validation_kpis enable row level security;
alter table public.pilot_leads enable row level security;
alter table public.waitlist_signups enable row level security;

create policy "Users can read own profile" on public.profiles
  for select using (auth.uid() = id);

create policy "Users can create own profile" on public.profiles
  for insert with check (auth.uid() = id);

create policy "Users can update own profile" on public.profiles
  for update using (auth.uid() = id);

create policy "Admins can read all profiles" on public.profiles
  for select using (public.is_admin());

create policy "Public can read verified providers" on public.providers
  for select using (status = 'verified');

create policy "Admins can manage providers" on public.providers
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Providers can create own profile listing" on public.providers
  for insert with check (owner_id = auth.uid());

create policy "Providers can update own listing" on public.providers
  for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "Public can read gyms" on public.gyms
  for select using (true);

create policy "Admins can manage gyms" on public.gyms
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Public can read open provider availability" on public.provider_availability
  for select using (
    status = 'open'
    and exists (
      select 1 from public.providers
      where providers.id = provider_availability.provider_id
        and providers.status = 'verified'
    )
  );

create policy "Providers can manage own availability" on public.provider_availability
  for all using (
    exists (
      select 1 from public.providers
      where providers.id = provider_availability.provider_id
        and providers.owner_id = auth.uid()
    )
  ) with check (
    exists (
      select 1 from public.providers
      where providers.id = provider_availability.provider_id
        and providers.owner_id = auth.uid()
    )
  );

create policy "Admins can manage provider availability" on public.provider_availability
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Providers can manage own documents" on public.provider_documents
  for all using (
    exists (
      select 1 from public.providers
      where providers.id = provider_documents.provider_id
        and providers.owner_id = auth.uid()
    )
  ) with check (
    exists (
      select 1 from public.providers
      where providers.id = provider_documents.provider_id
        and providers.owner_id = auth.uid()
    )
  );

create policy "Admins can manage provider documents" on public.provider_documents
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Public can read approved provider reviews" on public.provider_reviews
  for select using (status = 'approved');

create policy "Users can create own provider reviews" on public.provider_reviews
  for insert with check (client_id = auth.uid() or client_id is null);

create policy "Admins can manage provider reviews" on public.provider_reviews
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Users can read own bookings" on public.bookings
  for select using (client_id = auth.uid());

create policy "Users can create own bookings" on public.bookings
  for insert with check (client_id = auth.uid());

create policy "Admins can manage bookings" on public.bookings
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Providers can read assigned bookings" on public.bookings
  for select using (
    exists (
      select 1 from public.providers
      where providers.id = bookings.provider_id
        and providers.owner_id = auth.uid()
    )
  );

create policy "Users can read own payments" on public.payments
  for select using (
    exists (
      select 1 from public.bookings
      where bookings.id = payments.booking_id
        and bookings.client_id = auth.uid()
    )
  );

create policy "Users can create own payments" on public.payments
  for insert with check (
    exists (
      select 1 from public.bookings
      where bookings.id = payments.booking_id
        and bookings.client_id = auth.uid()
    )
  );

create policy "Admins can manage payments" on public.payments
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Providers can read assigned payments" on public.payments
  for select using (
    exists (
      select 1
      from public.bookings
      join public.providers on providers.id = bookings.provider_id
      where bookings.id = payments.booking_id
        and providers.owner_id = auth.uid()
    )
  );

create policy "Admins can manage payment events" on public.payment_events
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Users can read own health metrics" on public.health_metrics
  for select using (client_id = auth.uid());

create policy "Users can insert own health metrics" on public.health_metrics
  for insert with check (client_id = auth.uid());

create policy "Admins can read all health metrics" on public.health_metrics
  for select using (public.is_admin());

create policy "Admins can manage corporate employees" on public.corporate_employees
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage corporate challenges" on public.corporate_challenges
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage corporate screenings" on public.corporate_screenings
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Users can create own consent records" on public.consent_records
  for insert with check (user_id = auth.uid() or user_id is null);

create policy "Users can read own consent records" on public.consent_records
  for select using (user_id = auth.uid());

create policy "Admins can read consent records" on public.consent_records
  for select using (public.is_admin());

create policy "Users can create deletion requests" on public.account_deletion_requests
  for insert with check (user_id = auth.uid() or user_id is null);

create policy "Users can read own deletion requests" on public.account_deletion_requests
  for select using (user_id = auth.uid());

create policy "Admins can manage deletion requests" on public.account_deletion_requests
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage notifications" on public.notifications
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Users can read own notifications" on public.notifications
  for select using (user_id = auth.uid() or user_id is null);

create policy "Users can create support tickets" on public.support_tickets
  for insert with check (user_id = auth.uid() or user_id is null);

create policy "Users can read own support tickets" on public.support_tickets
  for select using (user_id = auth.uid());

create policy "Admins can manage support tickets" on public.support_tickets
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage pilot validation KPIs" on public.pilot_validation_kpis
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins can manage pilot leads" on public.pilot_leads
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Users can create waitlist signups" on public.waitlist_signups
  for insert with check (user_id = auth.uid() or user_id is null);

create policy "Users can read own waitlist signups" on public.waitlist_signups
  for select using (user_id = auth.uid());

create policy "Admins can manage waitlist signups" on public.waitlist_signups
  for all using (public.is_admin()) with check (public.is_admin());
