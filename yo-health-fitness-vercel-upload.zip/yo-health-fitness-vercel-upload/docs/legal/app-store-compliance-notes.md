# App Store Compliance Notes

## Required Before Submission

- Public privacy policy URL.
- Terms of service URL.
- Health disclaimer inside the app.
- Account deletion request path.
- Support email.
- Demo account for review.
- Clear explanation that AI guidance is wellness support, not medical advice.
- No stored card details inside the app.

## Health Data Safety

If the app stores health or wellness data, use clear consent, access controls, and data deletion workflows. Corporate dashboards should avoid exposing individual health data without explicit consent.

## iOS And Android Review

Apple and Google may scrutinize health claims, AI claims, payment flows, subscriptions, account deletion, and privacy disclosures. Keep claims conservative and document every data type collected.
