# Terms Of Service Draft

Status: lawyer-review draft for product planning, app-store review preparation, and buyer handoff.

Add the final company legal name, registered address, governing law, dispute venue, support email, and effective date before launch.

## Marketplace Role

YO Health & Fitness operates as a marketplace and software platform that connects users with independent trainers, coaches, gyms, clinics, wellness providers, corporate wellness services, and concierge wellness services.

Unless otherwise stated in a signed agreement, providers are independent third parties and are not employees of YO Health & Fitness.

## Eligibility

Users must be legally able to use the service and must provide accurate account information. Users should not use the service if they are prohibited from doing so under applicable law or app-store rules.

## User Responsibility

Users are responsible for:

- Providing accurate profile, booking, and health/wellness information.
- Choosing services suitable for their personal condition.
- Consulting qualified healthcare professionals before starting exercise, diet, recovery, physiotherapy, or wellness programs.
- Stopping activity and seeking help if they experience pain, injury, or urgent symptoms.
- Treating providers, staff, and other users respectfully.

## Provider Responsibility

Providers are responsible for:

- Accurate listing information.
- Valid credentials, licenses, certifications, insurance, and legal authority to provide services.
- Safe conduct during sessions.
- Compliance with UAE and Dubai requirements applicable to their services.
- Client confidentiality and responsible data handling.
- Not making misleading medical, transformation, or guaranteed-result claims.

## Bookings

The final launch terms should define:

- Booking request process.
- Provider confirmation rules.
- Rescheduling windows.
- Cancellation rules.
- No-show rules.
- Refund rules.
- Late arrival rules.
- Home, gym, hotel, villa, online, and corporate session conditions.

## Payments

Payments should use hosted checkout. YO Health & Fitness should not store raw card details.

The final launch terms should define:

- Commission percentage.
- Deposit and full-payment rules.
- Provider payout timeline.
- Refund handling.
- Chargeback handling.
- Taxes, invoices, and receipts.
- Currency: AED for UAE launch unless otherwise stated.

## AI Guidance

AI coaching features provide general wellness support only. They are not medical advice, diagnosis, treatment, emergency support, or clinical decision-making.

Users should not rely on AI guidance for urgent health issues, medication decisions, injury diagnosis, disease treatment, or major lifestyle changes without qualified professional advice.

## Health And Regulated Services

Nutrition, physiotherapy, health screenings, injury recovery, clinical advice, or medical-adjacent services may require licensed professionals, additional disclaimers, or regulatory approvals. These services should not be launched publicly until reviewed by UAE legal/compliance counsel.

## Reviews And Content

Users may submit reviews, messages, notes, or other content. YO Health & Fitness may moderate, remove, reject, or restrict content that is false, abusive, discriminatory, unsafe, spam, illegal, defamatory, or not based on a real experience.

## Account Removal

The platform may suspend, restrict, or remove accounts, listings, bookings, reviews, or content that are unsafe, misleading, illegal, abusive, unverified, or in breach of the terms.

## Corporate Wellness

Corporate wellness features should be governed by a separate business agreement covering employee consent, reporting, data use, confidentiality, payment, service scope, and liability.

## Limitation Of Liability

Add a lawyer-approved limitation of liability clause before launch. It should account for marketplace status, provider independence, health/wellness risk, payment provider reliance, and applicable UAE law.

## Legal Review Notes

Review against applicable UAE consumer protection rules, marketplace/ecommerce obligations, privacy laws, health-service regulations, app-store rules, and payment-provider requirements.
