# Privacy Policy Draft

Status: lawyer-review draft for product planning, app-store review preparation, and buyer handoff.

Add the final company legal name, registered address, privacy contact, support email, and policy effective date before launch.

## Scope

YO Health & Fitness is a health, fitness, and wellness marketplace. The platform may support client accounts, provider accounts, corporate wellness accounts, bookings, gym discovery, wellness metrics, provider verification, support tickets, notifications, and hosted checkout records.

## Data Collected

The platform may collect:

- Account data: name, email, phone, role, login data, profile settings.
- Client wellness data: goals, body metrics, health metrics, fitness metrics, sleep, stress, activity, recovery, and user-entered notes.
- Booking data: provider, service, date/time, location type, notes, booking status, payment status.
- Provider data: listings, pricing, availability, reviews, verification document links, qualifications, certification notes.
- Corporate wellness data: company name, employee roster fields, challenge participation, screening requests, aggregated wellness reporting.
- Payment records: amount, commission, provider payout, reference, hosted checkout URL, external payment provider ID, payment status.
- Trust and support data: consent records, deletion requests, support tickets, notification records, moderation decisions.

## Sensitive Data

Health and wellness information should be treated as sensitive. The production platform should use role-based access controls, row-level security, limited employee/admin access, and clear deletion workflows.

Provider identity documents, certificates, insurance records, or license evidence should not be stored publicly. For production, store these in a private storage bucket with signed URLs or another secure document workflow.

## How Data Is Used

Data may be used to:

- Create and manage user accounts.
- Match clients with providers, gyms, wellness services, and corporate programs.
- Process bookings and hosted checkout records.
- Show wellness dashboards and AI-supported wellness suggestions.
- Verify providers and moderate reviews.
- Provide customer support and operational notifications.
- Detect misuse, fraud, unsafe conduct, or policy violations.
- Improve the app and prepare aggregated business reporting.

## AI And Wellness Features

AI-supported features provide general wellness suggestions only. They should not be used for medical diagnosis, treatment, emergency support, or clinical decision-making.

## Corporate Wellness

Corporate dashboards should prioritize aggregated reporting. Individual employee data should only be shared with clear consent, contractual authority, or another lawful basis approved by legal counsel.

## Payments

YO Health & Fitness should not collect or store raw card details. Production payment processing should use hosted checkout from Stripe, Tap, Checkout.com, Ziina, Network International, or another approved payment provider. Payment provider terms and privacy policies should be disclosed before launch.

## Data Sharing

Data may be shared with:

- Providers selected by the user for bookings.
- Corporate account administrators only where permitted and appropriately aggregated or consented.
- Payment providers for hosted checkout.
- Supabase or other backend infrastructure providers.
- Legal, compliance, accounting, or safety advisors where required.
- Authorities where legally required.

## User Rights

Users should be able to request:

- Access to their data.
- Correction of inaccurate data.
- Deletion of their account.
- Withdrawal of optional consent where applicable.
- Information about how their data is used.

The Trust Center includes consent and account deletion request flows. For production, connect these flows to an operational support process and response timeline approved by counsel.

## Retention

Define a production retention schedule before launch. Suggested review categories:

- Account records.
- Booking and payment records.
- Health/wellness metrics.
- Provider verification records.
- Corporate wellness records.
- Support and trust records.

## Legal Review Notes

Review against applicable UAE privacy and data protection requirements, health-data rules, consumer protection obligations, app-store privacy disclosures, and any free-zone or mainland company obligations.

Official starting points:

- UAE data protection laws: https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws
- UAE consumer protection: https://u.ae/en/information-and-services/justice-safety-and-the-law/consumer-protection
- Dubai Health Authority regulations: https://www.dha.gov.ae/en/regulations
