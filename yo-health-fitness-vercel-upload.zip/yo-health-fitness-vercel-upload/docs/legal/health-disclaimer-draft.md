# Health Disclaimer Draft

Status: lawyer-review draft for product planning, app-store review preparation, and buyer handoff.

YO Health & Fitness provides wellness, booking, tracking, marketplace, and coaching support only.

## Not Medical Advice

The app is not a medical device. It does not provide medical advice, diagnosis, treatment, emergency care, clinical decision-making, prescription guidance, or disease-management instructions.

## Professional Advice

Users should consult qualified healthcare professionals before:

- Beginning a new exercise program.
- Changing diet or nutrition plans.
- Acting on AI recommendations.
- Acting on health metrics such as blood pressure, blood sugar, cholesterol, stress, sleep, recovery, body composition, or performance.
- Using physiotherapy, injury recovery, massage, screening, or medical-adjacent services.
- Exercising while pregnant, injured, ill, recovering from surgery, or managing a health condition.

## Emergency Warning

If a user experiences chest pain, severe shortness of breath, fainting, neurological symptoms, severe injury, allergic reaction, suicidal thoughts, or any urgent health issue, they should contact emergency services or a qualified healthcare provider immediately.

## AI Limitations

AI recommendations are general wellness suggestions and may be incomplete, inaccurate, outdated, or unsuitable for a specific user. AI output should be reviewed by qualified professionals before use in medical, clinical, nutrition, rehabilitation, or high-risk contexts.

## Provider Services

Providers are responsible for their professional qualifications, licenses, insurance, safety practices, and service suitability. Users should verify provider credentials and choose services appropriate for their needs.

## Health Metrics

Health and fitness metrics shown in the app may be manually entered, estimated, imported, or incomplete. They should not be treated as clinical measurements unless confirmed by qualified professionals using appropriate equipment.

## Regulated Services

Nutrition, physiotherapy, health screenings, injury recovery, medical massage, diagnostics, and other health-related services may require licensed professionals or regulatory approvals. These services should not be launched publicly until reviewed by UAE legal/compliance counsel.
