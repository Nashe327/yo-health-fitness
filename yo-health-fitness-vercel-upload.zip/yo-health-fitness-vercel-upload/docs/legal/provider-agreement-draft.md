# Provider Agreement Draft

Status: lawyer-review draft for provider onboarding, product planning, and buyer handoff.

Add the final company legal name, provider legal details, governing law, dispute venue, payout terms, commission terms, insurance requirements, and effective date before launch.

## Provider Status

The provider is an independent professional or business. The provider is not an employee, agent, partner, or representative of YO Health & Fitness unless a separate written agreement says otherwise.

## Provider Obligations

The provider must:

- Provide accurate profile, service, pricing, credential, and availability information.
- Hold all licenses, certifications, registrations, permissions, and insurance required for their services.
- Comply with applicable UAE and Dubai laws, regulations, professional rules, and venue rules.
- Deliver services safely, professionally, and respectfully.
- Avoid misleading claims, guaranteed-result claims, medical claims, or unauthorized health advice.
- Keep client information confidential.
- Report safety incidents, injuries, disputes, or complaints promptly.

## Verification

YO Health & Fitness may request:

- Professional certificates.
- Emirates ID or business identification.
- Insurance evidence.
- First aid certificate.
- Clinic, DHA, or other regulatory license where relevant.
- References, portfolio, or proof of experience.

YO Health & Fitness may approve, reject, suspend, or remove provider listings based on verification status, safety concerns, legal concerns, poor reviews, or policy violations.

## Regulated Services

Nutrition, physiotherapy, clinical screening, injury recovery, diagnostics, medical massage, rehabilitation, or medical-adjacent services may require specific licenses or regulatory approvals. Providers must not offer regulated services unless they are qualified and legally authorized to do so.

## Bookings

Provider must:

- Respond to booking requests promptly.
- Honor confirmed booking times or follow cancellation/rescheduling rules.
- Provide services only in agreed locations and formats.
- Use safe equipment and appropriate session plans.
- Avoid discriminatory, abusive, harassing, or unsafe conduct.

## Payments And Payouts

Final launch terms should define:

- Commission percentage.
- Deposit/full-payment rules.
- Payout schedule.
- Refund rules.
- Chargeback handling.
- Taxes and invoicing responsibility.
- Currency and settlement method.

Payment should be processed through hosted checkout or another approved payment flow. Providers should not ask users to bypass the platform unless explicitly allowed by written policy.

## Reviews And Moderation

Clients may submit reviews. YO Health & Fitness may moderate reviews for safety, abuse, fraud, relevance, and policy compliance. Providers may report reviews they believe are false or abusive, but they may not pressure clients to remove honest reviews.

## Data And Confidentiality

Providers must protect client information and use it only to deliver booked services. Providers must not sell, publish, or misuse client data.

## Safety And Incident Reporting

Providers must report:

- Injuries.
- Medical emergencies.
- Harassment or abuse.
- Property damage.
- Disputes.
- Suspected fraud.
- Any incident that may affect client safety or platform trust.

## Suspension And Termination

YO Health & Fitness may suspend or terminate provider access for:

- Failed verification.
- Expired or false credentials.
- Unsafe conduct.
- Repeated complaints.
- Fraud or payment abuse.
- Unauthorized medical claims.
- Breach of provider agreement or platform terms.

## Legal Review Notes

Review against UAE marketplace, employment/contractor, consumer protection, health licensing, data protection, insurance, payment, and dispute-resolution requirements before launch.
