# Buyer Handoff Checklist

Use this checklist if selling the app, pitching the idea, or handing it to a development buyer.

## Product Assets

- React/Vite app source code.
- Supabase schema and seed scripts.
- Capacitor iOS/Android configuration.
- App icons and web manifest.
- Pitch outline and demo video script.
- Outreach target list.
- Store listing draft.

## What To Show In A Demo

1. Open dashboard and show health command center metrics.
2. Log a new health metric and show the dashboard update.
3. Edit the client profile and explain personalization.
4. Search provider marketplace by service, location, and budget.
5. Open provider profile, choose an available slot, and request a booking.
6. Show booking confirmation, hosted checkout preparation, deposit/full-payment choice, and commission calculation.
7. Show gym marketplace.
8. Show AI coach recommendations.
9. Show corporate portal: add employee, launch challenge, request screening, and review executive report.
10. Show concierge and corporate wellness revenue potential.
11. Show provider portal for listing edits, availability, booking requests, and payouts.
12. Show trust center: documents, consent record, deletion request, and compliance notes.
13. Show sales package: valuation scenario, pitch, demo script, CRM, and handoff checklist.
14. Show admin booking and provider approval tools.

## What A Buyer Still Needs To Fund

- Final UI/UX refinement.
- Production Supabase hardening and database policies.
- Live payment gateway integration.
- Provider availability backend and calendar integration.
- Email and mobile push notifications.
- Provider verification workflow.
- Legal documents and health disclaimers.
- Final lawyer-reviewed privacy policy, terms, health disclaimer, and provider contracts.
- Native QA on real iOS and Android devices.
- Store submission and marketing website.

## Suggested Buyer Types

- UAE gym chains.
- Wellness clinic groups.
- Fitness marketplace operators.
- Corporate wellness companies.
- Luxury concierge companies.
- Sportswear and fitness brands expanding into digital services.
