# Reviewer Account Plan

Date: 2026-07-06

Use this for App Store Connect and Google Play review notes.

## Recommended Accounts

Create production Supabase accounts for reviewers:

| Role | Email | Purpose |
| --- | --- | --- |
| Client | `review-client@yohealthfitness.com` | Booking, dashboard, metrics, trust center |
| Provider | `review-provider@yohealthfitness.com` | Provider portal, verification docs, booking queue |
| Corporate | `review-corporate@yohealthfitness.com` | Corporate wellness dashboard |
| Admin | `review-admin@yohealthfitness.com` | Only if reviewer must inspect admin moderation |

Use strong temporary passwords and rotate after review.

## Recommended Review Notes

Use this copy in review submission:

```text
YO Health & Fitness is a wellness marketplace MVP for booking fitness and wellness providers, viewing gyms, tracking user-entered wellness metrics, and managing provider/corporate workflows.

The app is not a medical device and does not provide diagnosis, treatment, emergency support, or clinical decision-making. Health and AI features are general wellness support only.

Payments use hosted checkout records. The app does not collect or store raw card data.

Please use the supplied reviewer account. Demo/preview access is disabled in public builds unless explicitly provided for review.
```

## Review Flow

Ask reviewers to test:

- Sign in.
- Open dashboard.
- Browse marketplace.
- Open provider profile.
- Request booking.
- Create hosted checkout record.
- Submit provider review.
- Open Trust Center.
- Submit deletion request.

Admin-only review flow, if needed:

- Review provider applications.
- Review provider documents.
- Moderate provider reviews.
- View payment operations.

## Production Settings

For public review builds:

```text
VITE_ENABLE_DEMO_ACCESS=false
```

Only enable demo role switching for guided demos or internal QA.
