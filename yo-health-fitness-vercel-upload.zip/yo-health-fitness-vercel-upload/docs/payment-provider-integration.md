# Payment Provider Integration Plan

Date: 2026-07-06

YO Health & Fitness should use hosted checkout only. The app must never collect, process, or store raw card data.

## Recommended Shortlist

| Provider | Best For | Notes |
| --- | --- | --- |
| Stripe Checkout | Fast MVP/test launch | Strong docs and hosted checkout. Confirm UAE account eligibility and payout requirements. |
| Tap Payments | GCC/local payments | Good regional option for KNET/GCC-style payment expectations. Confirm fees and settlement. |
| Checkout.com | Enterprise UAE scale | Strong payment infrastructure; more enterprise-oriented onboarding. |
| Ziina | UAE-friendly payment links | Useful for early manual/SMB payment links. Confirm marketplace/payout support. |
| Network International | UAE enterprise acquiring | Strong local acquiring option; likely heavier onboarding. |

## Current App State

- Checkout creates a payment record.
- Payment record includes amount, commission, provider payout, method, reference, external provider, external payment ID, and hosted checkout URL.
- Demo checkout URLs use `https://payments.yohealthfitness.example/...`.
- Supabase schema includes `payments` and `payment_events`.
- Card details are not stored.

## Production Flow

1. Client confirms booking.
2. App calls backend function to create hosted checkout session.
3. Backend creates provider checkout session with selected payment provider.
4. Backend inserts/updates `payments`:
   - `booking_id`
   - `amount_aed`
   - `platform_fee_aed`
   - `provider_payout_aed`
   - `method`
   - `status = pending`
   - `reference`
   - `external_payment_id`
   - `external_provider`
   - `external_checkout_url`
5. Client opens hosted checkout URL.
6. Payment provider sends webhook.
7. Backend verifies webhook signature.
8. Backend inserts `payment_events`.
9. Backend updates `payments.status`.
10. Backend updates `bookings.payment_status`.

## Webhook Requirements

Webhook handler must:

- Verify provider signature.
- Reject duplicate events using `external_event_id`.
- Never trust client-side status updates.
- Update only known payment references.
- Store raw webhook payload in `payment_events.payload`.
- Map provider statuses to internal statuses:
  - `pending`
  - `paid`
  - `failed`
  - `refunded`

## Supabase Edge Function Shape

Suggested functions:

- `create-checkout-session`
- `payment-webhook`

Environment variables:

```text
PAYMENT_PROVIDER=stripe
PAYMENT_SECRET_KEY=...
PAYMENT_WEBHOOK_SECRET=...
PUBLIC_APP_URL=https://yourdomain.com
```

Do not expose secret keys to the React app.

## Marketplace Money Rules

- Default commission: 15%.
- Deposit mode: 25% of session price, minimum AED 50.
- Full payment mode: 100% of session price.
- Provider payout = collected amount minus platform fee.
- Refund and cancellation policy must be finalized before public launch.

## Launch Decision

For the first real launch, choose one payment provider only. Add others after the booking flow and payout operations are stable.
